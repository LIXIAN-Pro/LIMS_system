from fastapi import APIRouter, HTTPException
import database
from models import CollectorCreate, CollectorUpdate

router = APIRouter()

@router.get("/api/collectors")
async def get_collectors(status: str = None):
    """获取所有采集人员（可筛选状态）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 如果有状态参数，进行筛选
        if status:
            if status not in ["active", "inactive"]:
                raise HTTPException(status_code=400, detail="状态值必须是 'active' 或 'inactive'")
            query = "SELECT * FROM collectors WHERE status = %s ORDER BY created_at DESC"
            cursor.execute(query, (status,))
        else:
            query = "SELECT * FROM collectors ORDER BY created_at DESC"
            cursor.execute(query)
            
        collectors = cursor.fetchall()

        conn.close()

        return {"success": True, "data": collectors}

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取采集人员列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/collectors/available")
async def get_available_collectors():
    """获取可用的采集人员（状态为active）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM collectors WHERE status = 'active' ORDER BY name"
        cursor.execute(query)
        collectors = cursor.fetchall()

        conn.close()

        return {"success": True, "data": collectors}

    except Exception as e:
        print(f"获取可用采集人员列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/collectors/{collector_id}")
async def get_collector_by_id(collector_id: int):
    """获取单个采集人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM collectors WHERE id = %s"
        cursor.execute(query, (collector_id,))
        collector = cursor.fetchone()

        conn.close()

        if collector:
            return {"success": True, "data": collector}
        else:
            raise HTTPException(status_code=404, detail="采集人员不存在")

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取采集人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/collectors")
async def create_collector(collector: CollectorCreate):
    """创建采集人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查工号是否已存在
        check_query = "SELECT id FROM collectors WHERE employee_id = %s"
        cursor.execute(check_query, (collector.employee_id,))
        existing = cursor.fetchone()

        if existing:
            conn.close()
            raise HTTPException(status_code=400, detail="工号已存在")

        # 验证状态值
        if collector.status not in ["active", "inactive"]:
            conn.close()
            raise HTTPException(status_code=400, detail="状态值必须是 'active' 或 'inactive'")

        # 插入新记录
        insert_query = """
        INSERT INTO collectors
        (name, employee_id, phone, status)
        VALUES (%s, %s, %s, %s)
        """

        cursor.execute(insert_query, (
            collector.name,
            collector.employee_id,
            collector.phone,
            collector.status
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = "SELECT * FROM collectors WHERE id = LAST_INSERT_ID()"
        cursor.execute(get_query)
        new_collector = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "采集人员创建成功",
            "data": new_collector
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"创建采集人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/collectors/{collector_id}")
async def update_collector(collector_id: int, collector: CollectorUpdate):
    """更新采集人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM collectors WHERE id = %s"
        cursor.execute(check_query, (collector_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="采集人员不存在")

        # 检查工号是否与其他记录冲突
        check_employee_id = """
        SELECT id FROM collectors WHERE employee_id = %s AND id != %s
        """
        cursor.execute(check_employee_id, (collector.employee_id, collector_id))
        conflict = cursor.fetchone()

        if conflict:
            conn.close()
            raise HTTPException(status_code=400, detail="工号已被其他人员使用")

        # 验证状态值
        if collector.status not in ["active", "inactive"]:
            conn.close()
            raise HTTPException(status_code=400, detail="状态值必须是 'active' 或 'inactive'")

        # 更新记录
        update_query = """
        UPDATE collectors
        SET name = %s, employee_id = %s, phone = %s,
            status = %s, updated_at = NOW()
        WHERE id = %s
        """

        cursor.execute(update_query, (
            collector.name,
            collector.employee_id,
            collector.phone,
            collector.status,
            collector_id
        ))

        conn.commit()

        # 获取更新后的记录
        get_query = "SELECT * FROM collectors WHERE id = %s"
        cursor.execute(get_query, (collector_id,))
        updated_collector = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "采集人员更新成功",
            "data": updated_collector
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新采集人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/collectors/{collector_id}")
async def delete_collector(collector_id: int):
    """删除采集人员 - 允许删除有历史任务关联的人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id, name FROM collectors WHERE id = %s"
        cursor.execute(check_query, (collector_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="采集人员不存在")

        collector_name = existing['name']

        # 检查是否有进行中/待开始的任务关联该采集人员
        cursor.execute("""
            SELECT COUNT(*) as cnt
            FROM task_collectors tc
            JOIN tasks t ON tc.task_id = t.id
            WHERE tc.collector_id = %s AND t.status IN ('pending', 'in_progress')
        """, (collector_id,))
        active_count = cursor.fetchone()['cnt']
        if active_count > 0:
            conn.close()
            raise HTTPException(
                status_code=400,
                detail=f"该采集人员有 {active_count} 个进行中/待开始的任务，无法删除。请先取消相关任务。"
            )

        # 开启事务
        cursor.execute("START TRANSACTION")

        try:
            # 获取历史任务数量
            cursor.execute(
                "SELECT COUNT(*) as cnt FROM task_collectors WHERE collector_id = %s",
                (collector_id,)
            )
            history_count = cursor.fetchone()['cnt']

            # 解除所有任务关联（包括历史任务）
            cursor.execute(
                "DELETE FROM task_collectors WHERE collector_id = %s",
                (collector_id,)
            )

            # 删除采集人员记录
            cursor.execute("DELETE FROM collectors WHERE id = %s", (collector_id,))

            conn.commit()

            resource_info = f"，已解除 {history_count} 条历史任务关联" if history_count > 0 else ""

            conn.close()

            return {
                "success": True,
                "message": f"采集人员「{collector_name}」删除成功{resource_info}"
            }

        except Exception as tx_error:
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"删除采集人员事务失败: {str(tx_error)}")

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除采集人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/collectors/search/{keyword}")
async def search_collectors(keyword: str, status: str = None):
    """搜索采集人员（按姓名或工号）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        search_pattern = f"%{keyword}%"
        
        if status:
            if status not in ["active", "inactive"]:
                raise HTTPException(status_code=400, detail="状态值必须是 'active' 或 'inactive'")
            query = """
            SELECT * FROM collectors
            WHERE (name LIKE %s OR employee_id LIKE %s)
            AND status = %s
            ORDER BY created_at DESC
            """
            cursor.execute(query, (search_pattern, search_pattern, status))
        else:
            query = """
            SELECT * FROM collectors
            WHERE name LIKE %s OR employee_id LIKE %s
            ORDER BY created_at DESC
            """
            cursor.execute(query, (search_pattern, search_pattern))
            
        collectors = cursor.fetchall()

        conn.close()

        return {
            "success": True,
            "message": f"找到 {len(collectors)} 个匹配的采集人员",
            "data": collectors,
            "total": len(collectors)
        }

    except Exception as e:
        print(f"搜索采集人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
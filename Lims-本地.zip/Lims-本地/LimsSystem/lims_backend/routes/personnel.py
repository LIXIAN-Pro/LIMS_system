from fastapi import APIRouter, HTTPException
import database
from models import PersonnelCreate, PersonnelUpdate

router = APIRouter()

@router.get("/api/personnel")
async def get_personnel():
    """获取所有实验人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM lab_personnel ORDER BY created_at DESC"
        cursor.execute(query)
        personnel = cursor.fetchall()

        conn.close()

        return {"success": True, "data": personnel}

    except Exception as e:
        print(f"获取实验人员列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/personnel/{personnel_id}")
async def get_personnel_by_id(personnel_id: int):
    """获取单个实验人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM lab_personnel WHERE id = %s"
        cursor.execute(query, (personnel_id,))
        person = cursor.fetchone()

        conn.close()

        if person:
            return {"success": True, "data": person}
        else:
            raise HTTPException(status_code=404, detail="实验人员不存在")

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取实验人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/personnel")
async def create_personnel(personnel: PersonnelCreate):
    """创建实验人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查工号是否已存在
        check_query = "SELECT id FROM lab_personnel WHERE employee_id = %s"
        cursor.execute(check_query, (personnel.employee_id,))
        existing = cursor.fetchone()

        if existing:
            conn.close()
            raise HTTPException(status_code=400, detail="工号已存在")

        # 插入新记录
        insert_query = """
        INSERT INTO lab_personnel
        (name, employee_id, phone, department, responsibility, status)
        VALUES (%s, %s, %s, %s, %s, %s)
        """

        cursor.execute(insert_query, (
            personnel.name,
            personnel.employee_id,
            personnel.phone,
            personnel.department,
            personnel.responsibility,
            personnel.status
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = "SELECT * FROM lab_personnel WHERE id = LAST_INSERT_ID()"
        cursor.execute(get_query)
        new_person = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "实验人员创建成功",
            "data": new_person
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"创建实验人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/personnel/{personnel_id}")
async def update_personnel(personnel_id: int, personnel: PersonnelUpdate):
    """更新实验人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM lab_personnel WHERE id = %s"
        cursor.execute(check_query, (personnel_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="实验人员不存在")

        # 检查工号是否与其他记录冲突
        check_employee_id = """
        SELECT id FROM lab_personnel WHERE employee_id = %s AND id != %s
        """
        cursor.execute(check_employee_id, (personnel.employee_id, personnel_id))
        conflict = cursor.fetchone()

        if conflict:
            conn.close()
            raise HTTPException(status_code=400, detail="工号已被其他人员使用")

        # 更新记录
        update_query = """
        UPDATE lab_personnel
        SET name = %s, employee_id = %s, phone = %s,
            department = %s, responsibility = %s, status = %s,
            updated_at = NOW()
        WHERE id = %s
        """

        cursor.execute(update_query, (
            personnel.name,
            personnel.employee_id,
            personnel.phone,
            personnel.department,
            personnel.responsibility,
            personnel.status,
            personnel_id
        ))

        conn.commit()

        # 获取更新后的记录
        get_query = "SELECT * FROM lab_personnel WHERE id = %s"
        cursor.execute(get_query, (personnel_id,))
        updated_person = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "实验人员更新成功",
            "data": updated_person
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新实验人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/personnel/{personnel_id}")
async def delete_personnel(personnel_id: int):
    """删除实验人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM lab_personnel WHERE id = %s"
        cursor.execute(check_query, (personnel_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="实验人员不存在")

        # 删除记录
        delete_query = "DELETE FROM lab_personnel WHERE id = %s"
        cursor.execute(delete_query, (personnel_id,))

        conn.commit()

        conn.close()

        return {
            "success": True,
            "message": "实验人员删除成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除实验人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
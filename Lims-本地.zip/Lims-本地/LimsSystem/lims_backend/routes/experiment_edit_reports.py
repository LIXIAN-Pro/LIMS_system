# routes/experiment_edit_reports.py
from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Body
from fastapi.responses import FileResponse
import database
import os
from datetime import datetime
from typing import Optional
import uuid
import urllib.parse
import mimetypes

router = APIRouter()

# 上传目录
UPLOAD_DIR = "uploads/experiment_edit_reports"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/api/experiment-edit-reports/upload")
async def upload_experiment_edit_report(
    experiment_report_id: int = Form(...),
    file: UploadFile = File(...)
):
    """上传实验编制报告"""
    try:
        # 验证文件类型
        allowed_extensions = {'.doc', '.docx', '.pdf', '.xlsx', '.xls'}
        file_extension = os.path.splitext(file.filename)[1].lower()

        if file_extension not in allowed_extensions:
            raise HTTPException(status_code=400, detail="只允许上传Word、PDF、Excel格式的文件")

        # 验证文件大小（限制为50MB）
        max_size = 50 * 1024 * 1024  # 50MB
        if file.size and file.size > max_size:
            raise HTTPException(status_code=400, detail="文件大小不能超过50MB")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 验证实验报告是否存在
        check_query = "SELECT id FROM experiment_reports WHERE id = %s"
        cursor.execute(check_query, (experiment_report_id,))
        experiment_report = cursor.fetchone()

        if not experiment_report:
            conn.close()
            raise HTTPException(status_code=404, detail="实验报告不存在")

        # 检查是否已为该实验报告上传过编制报告
        check_edit_query = "SELECT id FROM experiment_edit_reports WHERE experiment_report_id = %s"
        cursor.execute(check_edit_query, (experiment_report_id,))
        existing_edit_report = cursor.fetchone()

        if existing_edit_report:
            conn.close()
            raise HTTPException(status_code=400, detail="该实验报告已上传编制报告")

        # 生成唯一文件名
        unique_filename = f"{uuid.uuid4().hex}_{file.filename}"
        file_path = os.path.join(UPLOAD_DIR, unique_filename)

        # 保存文件
        try:
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
        except Exception as e:
            print(f"文件保存失败: {e}")
            raise HTTPException(status_code=500, detail="文件保存失败")

        # 插入数据库记录
        insert_query = """
        INSERT INTO experiment_edit_reports
        (experiment_report_id, filename, original_filename, file_path, file_size, status, review_level, review_status)
        VALUES (%s, %s, %s, %s, %s, 'uploaded', 1, 'pending')
        """

        cursor.execute(insert_query, (
            experiment_report_id,
            unique_filename,
            file.filename,
            file_path,
            file.size or len(content),
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = """
        SELECT eer.*, er.project_code, er.project_name, er.personnel_name
        FROM experiment_edit_reports eer
        LEFT JOIN experiment_reports er ON eer.experiment_report_id = er.id
        WHERE eer.id = LAST_INSERT_ID()
        """
        cursor.execute(get_query)
        new_edit_report = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "实验编制报告上传成功",
            "data": new_edit_report
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"上传实验编制报告错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/experiment-edit-reports")
async def get_experiment_edit_reports():
    """获取所有实验编制报告列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT eer.*, er.project_code, er.project_name, er.personnel_name, er.project_id
        FROM experiment_edit_reports eer
        LEFT JOIN experiment_reports er ON eer.experiment_report_id = er.id
        ORDER BY eer.upload_time DESC
        """

        # 首先确保表有审核字段，如果没有则添加
        try:
            alter_query = """
            ALTER TABLE experiment_edit_reports
            ADD COLUMN IF NOT EXISTS review_status VARCHAR(20) DEFAULT NULL,
            ADD COLUMN IF NOT EXISTS review_level INT DEFAULT 1,
            ADD COLUMN IF NOT EXISTS review_notes TEXT,
            ADD COLUMN IF NOT EXISTS reviewed_by VARCHAR(100),
            ADD COLUMN IF NOT EXISTS reviewed_at DATETIME DEFAULT NULL
            """
            cursor.execute(alter_query)
            conn.commit()
        except Exception as e:
            print(f"添加审核字段失败（可能已存在）: {e}")
        cursor.execute(query)
        edit_reports = cursor.fetchall()

        conn.close()

        return {"success": True, "data": edit_reports}

    except Exception as e:
        print(f"获取实验编制报告列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/experiment-edit-reports/{experiment_report_id}")
async def get_experiment_edit_report(experiment_report_id: int):
    """获取单个实验报告的编制报告"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT eer.*, er.project_code, er.project_name, er.personnel_name
        FROM experiment_edit_reports eer
        LEFT JOIN experiment_reports er ON eer.experiment_report_id = er.id
        WHERE eer.experiment_report_id = %s
        """
        cursor.execute(query, (experiment_report_id,))
        edit_report = cursor.fetchone()

        conn.close()

        return {"success": True, "data": edit_report}

    except Exception as e:
        print(f"获取实验编制报告错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/experiment-edit-reports/download/{edit_report_id}")
async def download_experiment_edit_report(edit_report_id: int):
    """下载实验编制报告"""
    try:
        print(f"下载请求: edit_report_id={edit_report_id}")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM experiment_edit_reports WHERE id = %s"
        cursor.execute(query, (edit_report_id,))
        edit_report = cursor.fetchone()

        conn.close()

        if not edit_report:
            print(f"报告不存在: id={edit_report_id}")
            raise HTTPException(status_code=404, detail="实验编制报告不存在")

        print(f"数据库中的文件路径: {edit_report['file_path']}")
        print(f"当前工作目录: {os.getcwd()}")

        # 确保使用绝对路径
        if not os.path.isabs(edit_report['file_path']):
            # 如果是相对路径，相对于后端目录
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            file_path = os.path.join(backend_dir, edit_report['file_path'])
            print(f"转换为绝对路径: {file_path}")
        else:
            file_path = edit_report['file_path']

        print(f"最终文件路径: {file_path}")
        print(f"文件是否存在: {os.path.exists(file_path)}")

        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail=f"文件不存在: {file_path}")

        # 根据文件扩展名确定正确的MIME类型
        mime_type, _ = mimetypes.guess_type(edit_report['original_filename'])
        if mime_type is None:
            mime_type = 'application/octet-stream'

        print(f"准备下载文件: {file_path}, MIME类型: {mime_type}")

        # 设置正确的Content-Disposition头，确保文件名正确编码
        encoded_filename = urllib.parse.quote(edit_report['original_filename'])
        headers = {
            'Content-Disposition': f'attachment; filename*=UTF-8\'\'{encoded_filename}'
        }

        return FileResponse(
            path=file_path,
            filename=edit_report['original_filename'],
            media_type=mime_type,
            headers=headers
        )

    except HTTPException:
        raise
    except Exception as e:
        print(f"下载实验编制报告错误: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/experiment-edit-reports/{edit_report_id}")
async def delete_experiment_edit_report(edit_report_id: int):
    """删除实验编制报告"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 获取编制报告信息
        query = "SELECT * FROM experiment_edit_reports WHERE id = %s"
        cursor.execute(query, (edit_report_id,))
        edit_report = cursor.fetchone()

        if not edit_report:
            conn.close()
            raise HTTPException(status_code=404, detail="实验编制报告不存在")

        # 删除文件
        if os.path.exists(edit_report['file_path']):
            try:
                os.remove(edit_report['file_path'])
            except Exception as e:
                print(f"删除文件失败: {e}")

        # 删除数据库记录
        delete_query = "DELETE FROM experiment_edit_reports WHERE id = %s"
        cursor.execute(delete_query, (edit_report_id,))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "实验编制报告删除成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除实验编制报告错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/experiment-edit-reports/{edit_report_id}/history")
async def get_edit_report_history(edit_report_id: int):
    """获取编制报告的审核历史记录"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 获取编制报告信息
        query = """
        SELECT eer.*, er.project_code, er.project_name
        FROM experiment_edit_reports eer
        LEFT JOIN experiment_reports er ON eer.experiment_report_id = er.id
        WHERE eer.id = %s
        """
        cursor.execute(query, (edit_report_id,))
        edit_report = cursor.fetchone()

        if not edit_report:
            conn.close()
            raise HTTPException(status_code=404, detail="实验编制报告不存在")

        # 构建审核历史
        history = []

        # 1. 上传记录
        history.append({
            "action": "upload",
            "action_text": "上传编制报告",
            "description": f"上传了文件「{edit_report['original_filename']}」",
            "operator": None,
            "timestamp": edit_report.get('upload_time')
        })

        # 2. 二级审核记录
        if edit_report.get('review_level') and edit_report.get('review_level') >= 1:
            if edit_report.get('review_status') == 'rejected' and edit_report.get('review_level') == 1:
                history.append({
                    "action": "secondary_reject",
                    "action_text": "二级审核驳回",
                    "description": f"驳回原因：{edit_report.get('review_notes') or '无'}",
                    "operator": edit_report.get('reviewed_by'),
                    "timestamp": edit_report.get('reviewed_at')
                })
            elif edit_report.get('review_status') == 'approved' and edit_report.get('review_level') >= 2:
                history.append({
                    "action": "secondary_approve",
                    "action_text": "二级审核通过",
                    "description": "报告已通过二级审核",
                    "operator": edit_report.get('reviewed_by'),
                    "timestamp": edit_report.get('reviewed_at')
                })

        # 3. 三级审核记录（如果有）
        if edit_report.get('review_level') == 3:
            history.append({
                "action": "tertiary_complete",
                "action_text": "三级审核完成",
                "description": "报告已完成全部审核流程",
                "operator": edit_report.get('reviewed_by'),
                "timestamp": edit_report.get('reviewed_at')
            })

        # 按时间排序
        history.sort(key=lambda x: x['timestamp'] or '', reverse=True)

        conn.close()

        return {
            "success": True,
            "data": {
                "report_info": {
                    "id": edit_report['id'],
                    "project_code": edit_report.get('project_code'),
                    "project_name": edit_report.get('project_name'),
                    "filename": edit_report.get('original_filename'),
                    "status": edit_report.get('status'),
                    "review_level": edit_report.get('review_level'),
                    "review_status": edit_report.get('review_status')
                },
                "history": history
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取审核历史错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
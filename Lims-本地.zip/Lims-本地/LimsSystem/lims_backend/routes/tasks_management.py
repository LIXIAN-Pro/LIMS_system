# routes/tasks_management.py
from fastapi import APIRouter
from fastapi.responses import HTMLResponse
import os

router = APIRouter()

# 获取HTML文件路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML_FILE = os.path.join(BASE_DIR, "templates", "tasks_management.html")

@router.get("/tasks-management", response_class=HTMLResponse)
async def get_tasks_management_page():
    """返回进行中任务管理页面"""
    try:
        with open(HTML_FILE, 'r', encoding='utf-8') as f:
            html_content = f.read()
        return HTMLResponse(content=html_content)
    except FileNotFoundError:
        return HTMLResponse(content="<h1>页面文件未找到</h1><p>请确保templates/tasks_management.html文件存在</p>", status_code=404)
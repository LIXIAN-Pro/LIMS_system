from fastapi import APIRouter, HTTPException
import database
from models import LabInfoCreate

router = APIRouter()

@router.get("/api/lab-info")
async def get_lab_info():
    """获取实验室信息"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM laboratory_info ORDER BY id DESC LIMIT 1"
        cursor.execute(query)
        lab_info = cursor.fetchone()

        conn.close()

        if lab_info:
            return {"success": True, "data": lab_info}
        else:
            return {"success": True, "data": None}

    except Exception as e:
        print(f"获取实验室信息错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/lab-info")
async def save_lab_info(lab_data: LabInfoCreate):
    """保存实验室信息"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查是否已存在记录
        check_query = "SELECT id FROM laboratory_info ORDER BY id DESC LIMIT 1"
        cursor.execute(check_query)
        existing = cursor.fetchone()

        if existing:
            # 更新现有记录
            update_query = """
            UPDATE laboratory_info
            SET name = %s, director = %s, code = %s, phone = %s,
                address = %s, description = %s, logo = %s, status = %s,
                updated_at = NOW()
            WHERE id = %s
            """
            cursor.execute(update_query, (
                lab_data.name, lab_data.director, lab_data.code,
                lab_data.phone, lab_data.address, lab_data.description,
                lab_data.logo, lab_data.status, existing["id"]
            ))
            message = "实验室信息更新成功"
            lab_id = existing["id"]
        else:
            # 创建新记录（设置一个默认的user_id，比如1）
            insert_query = """
            INSERT INTO laboratory_info
            (name, director, code, phone, address, description, logo, status, user_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(insert_query, (
                lab_data.name, lab_data.director, lab_data.code,
                lab_data.phone, lab_data.address, lab_data.description,
                lab_data.logo, lab_data.status, 1  # 使用默认用户ID
            ))
            message = "实验室信息创建成功"
            lab_id = cursor.lastrowid

        conn.commit()

        # 获取保存后的数据
        get_query = "SELECT * FROM laboratory_info WHERE id = %s"
        cursor.execute(get_query, (lab_id,))
        saved_info = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": message,
            "data": saved_info
        }

    except Exception as e:
        print(f"保存实验室信息错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
# routes/collection_templates.py
from fastapi import APIRouter, HTTPException, UploadFile, File
import os
import shutil
import uuid
import database

router = APIRouter()

# 文件上传配置
UPLOAD_DIR = "uploads/collection_templates"
ALLOWED_EXTENSIONS = {
    'doc', 'docx', 'xls', 'xlsx', 'pdf', 'txt',
    'jpg', 'jpeg', 'png', 'gif'
}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

# 确保上传目录存在
os.makedirs(UPLOAD_DIR, exist_ok=True)

def allowed_file(filename: str) -> bool:
    """检查文件扩展名是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 1. 上传采集表文件
@router.post("/api/collection-templates/upload")
async def upload_collection_template(file: UploadFile = File(...)):
    """上传采集表文件"""
    try:
        # 验证文件
        if not file.filename:
            raise HTTPException(status_code=400, detail="文件名不能为空")
        
        if not allowed_file(file.filename):
            allowed = ", ".join(ALLOWED_EXTENSIONS)
            raise HTTPException(
                status_code=400, 
                detail=f"不支持的文件格式。允许的格式: {allowed}"
            )
        
        # 生成唯一文件名
        file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        unique_filename = f"{uuid.uuid4().hex}.{file_ext}"
        original_filename = file.filename
        file_path = os.path.join(UPLOAD_DIR, unique_filename)
        
        # 保存文件
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # 获取文件信息
        file_size = os.path.getsize(file_path)
        
        # 保存到数据库
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        insert_query = """
        INSERT INTO collection_templates 
        (file_name, file_path, file_size, file_format)
        VALUES (%s, %s, %s, %s)
        """
        
        cursor.execute(insert_query, (
            original_filename,
            file_path,
            file_size,
            file_ext.upper()
        ))
        
        # 获取刚插入的记录ID
        template_id = cursor.lastrowid
        
        # 获取刚插入的记录
        get_query = "SELECT * FROM collection_templates WHERE id = %s"
        cursor.execute(get_query, (template_id,))
        new_template = cursor.fetchone()
        
        conn.commit()
        conn.close()
        
        return {
            "success": True,
            "message": "文件上传成功",
            "data": new_template
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"上传文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

# 2. 获取所有采集表文件
@router.get("/api/collection-templates")
async def get_collection_templates():
    """获取所有采集表文件"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        query = """
        SELECT * FROM collection_templates 
        ORDER BY created_at DESC
        """
        cursor.execute(query)
        templates = cursor.fetchall()
        
        conn.close()
        return {"success": True, "data": templates}
        
    except Exception as e:
        print(f"获取采集表列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

# 3. 下载采集表文件
@router.get("/api/collection-templates/{template_id}/download")
async def download_collection_template(template_id: int):
    """下载采集表文件"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 获取文件信息
        query = "SELECT file_name, file_path FROM collection_templates WHERE id = %s"
        cursor.execute(query, (template_id,))
        template = cursor.fetchone()
        
        if not template:
            conn.close()
            raise HTTPException(status_code=404, detail="文件不存在")
        
        # 检查文件是否存在
        if not os.path.exists(template['file_path']):
            conn.close()
            raise HTTPException(status_code=404, detail="文件不存在或已被删除")
        
        # 返回文件信息（实际下载由前端处理）
        conn.close()
        
        return {
            "success": True,
            "message": "文件获取成功",
            "data": {
                "file_name": template['file_name'],
                "file_path": template['file_path'],
                "download_url": f"/api/collection-templates/{template_id}/file"
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"下载文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

# 4. 获取文件内容（用于直接下载）
@router.get("/api/collection-templates/{template_id}/file")
async def get_template_file(template_id: int):
    """获取文件内容"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 获取文件信息
        query = "SELECT file_name, file_path FROM collection_templates WHERE id = %s"
        cursor.execute(query, (template_id,))
        template = cursor.fetchone()
        
        if not template:
            conn.close()
            raise HTTPException(status_code=404, detail="文件不存在")
        
        # 检查文件是否存在
        if not os.path.exists(template['file_path']):
            conn.close()
            raise HTTPException(status_code=404, detail="文件不存在或已被删除")
        
        from fastapi.responses import FileResponse
        conn.close()
        
        return FileResponse(
            path=template['file_path'],
            filename=template['file_name'],
            media_type='application/octet-stream'
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"获取文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

# 5. 删除采集表文件
@router.delete("/api/collection-templates/{template_id}")
async def delete_collection_template(template_id: int):
    """删除采集表文件"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 获取文件信息
        query = "SELECT file_path FROM collection_templates WHERE id = %s"
        cursor.execute(query, (template_id,))
        template = cursor.fetchone()
        
        if not template:
            conn.close()
            raise HTTPException(status_code=404, detail="文件不存在")

        # 检查是否有任务正在引用该模板
        cursor.execute(
            "SELECT COUNT(*) as cnt FROM tasks WHERE template_id = %s AND status IN ('pending', 'in_progress')",
            (template_id,)
        )
        active_count = cursor.fetchone()['cnt']
        if active_count > 0:
            conn.close()
            raise HTTPException(
                status_code=400,
                detail=f"该采集表有 {active_count} 个进行中/待开始的任务正在使用，无法删除。请先取消相关任务。"
            )

        # 检查是否有任何历史任务引用
        cursor.execute("SELECT COUNT(*) as cnt FROM tasks WHERE template_id = %s", (template_id,))
        total_count = cursor.fetchone()['cnt']
        if total_count > 0:
            conn.close()
            raise HTTPException(
                status_code=400,
                detail=f"该采集表已被 {total_count} 个历史任务引用，为保留历史记录无法删除。"
            )

        # 删除数据库记录
        delete_query = "DELETE FROM collection_templates WHERE id = %s"
        cursor.execute(delete_query, (template_id,))
        
        # 删除物理文件
        try:
            if os.path.exists(template['file_path']):
                os.remove(template['file_path'])
        except Exception as e:
            print(f"删除物理文件失败: {e}")
            # 继续执行，至少数据库记录已删除
        
        conn.commit()
        conn.close()
        
        return {
            "success": True,
            "message": "文件删除成功"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"删除文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

# 6. 获取文件统计信息
@router.get("/api/collection-templates/stats")
async def get_template_stats():
    """获取文件统计信息"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 按格式统计
        format_query = """
        SELECT file_format, COUNT(*) as count 
        FROM collection_templates 
        GROUP BY file_format
        ORDER BY count DESC
        """
        cursor.execute(format_query)
        format_stats = cursor.fetchall()
        
        # 总文件数和总大小
        total_query = """
        SELECT 
            COUNT(*) as total_files,
            SUM(file_size) as total_size,
            AVG(file_size) as avg_size
        FROM collection_templates
        """
        cursor.execute(total_query)
        total_stats = cursor.fetchone()
        
        conn.close()
        
        return {
            "success": True,
            "data": {
                "format_stats": format_stats,
                "total_stats": total_stats
            }
        }
        
    except Exception as e:
        print(f"获取统计信息错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
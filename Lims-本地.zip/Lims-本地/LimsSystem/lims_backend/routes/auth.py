from fastapi import APIRouter, HTTPException, Header
import database
import auth as auth_module
from models import LoginRequest
from pydantic import BaseModel

router = APIRouter()

# 用户信息更新模型
class UserInfoUpdate(BaseModel):
    name: str
    email: str

# 新增用户模型
class AddUserRequest(BaseModel):
    username: str
    password: str
    role: str
    name: str
    email: str

@router.post("/api/auth/login")
async def login(login_data: LoginRequest):
    try:
        # 获取数据库连接
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 查询用户
        query = "SELECT * FROM lab_staff WHERE username = %s AND role = %s"
        cursor.execute(query, (login_data.username, login_data.role))
        user = cursor.fetchone()

        if not user:
            conn.close()
            raise HTTPException(status_code=401, detail="账号不存在或角色错误")

        # 直接比较明文密码
        if login_data.password != user["password"]:  # ✅ 改为password
            conn.close()
            raise HTTPException(status_code=401, detail="密码错误")

        # 创建JWT令牌
        token = auth_module.create_access_token({
            "sub": user["username"],
            "role": user["role"],
            "user_id": user["id"]
        })

        conn.close()

        return {
            "success": True,
            "message": "登录成功",
            "token": {
                "access_token": token,
                "token_type": "bearer"
            },
            "username": user["username"],
            "name": user.get("name", ""),
            "email": user.get("email", ""),
            "role": user["role"]
        }

    except Exception as e:
        print(f"登录错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/auth/user-info")
async def get_user_info(authorization: str = Header(None)):
    """获取当前用户信息"""
    try:
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="缺少认证信息")

        token = authorization.replace("Bearer ", "")
        payload = auth_module.verify_token(token)

        if not payload:
            raise HTTPException(status_code=401, detail="无效的token")

        # 获取用户详细信息
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT id, username, name, email, role, created_at, updated_at FROM lab_staff WHERE id = %s"
        cursor.execute(query, (payload["user_id"],))
        user = cursor.fetchone()

        conn.close()

        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")

        return {
            "success": True,
            "data": {
                "id": user["id"],
                "username": user["username"],
                "name": user["name"] or "",
                "email": user["email"] or "",
                "role": user["role"],
                "created_at": user["created_at"],
                "updated_at": user["updated_at"]
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取用户信息错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/auth/update-user-info")
async def update_user_info(user_update: UserInfoUpdate, authorization: str = Header(None)):
    """更新用户信息"""
    try:
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="缺少认证信息")

        token = authorization.replace("Bearer ", "")
        payload = auth_module.verify_token(token)

        if not payload:
            raise HTTPException(status_code=401, detail="无效的token")

        # 验证邮箱唯一性
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查邮箱是否已被其他用户使用
        cursor.execute(
            "SELECT id FROM lab_staff WHERE email = %s AND id != %s",
            (user_update.email, payload["user_id"])
        )
        existing_user = cursor.fetchone()

        if existing_user:
            conn.close()
            raise HTTPException(status_code=400, detail="邮箱已被其他用户使用")

        # 更新用户信息
        update_query = """
        UPDATE lab_staff
        SET name = %s, email = %s, updated_at = NOW()
        WHERE id = %s
        """
        cursor.execute(update_query, (
            user_update.name,
            user_update.email,
            payload["user_id"]
        ))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "用户信息更新成功",
            "data": {
                "name": user_update.name,
                "email": user_update.email
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新用户信息错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/auth/add-user")
async def add_user(user_data: AddUserRequest, authorization: str = Header(None)):
    """新增用户（管理员权限）"""
    try:
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="缺少认证信息")

        token = authorization.replace("Bearer ", "")
        print(f"[DEBUG] add-user token: {token[:20]}...")  # 只打印前20个字符用于调试

        payload = auth_module.verify_token(token)

        if not payload:
            print(f"[DEBUG] Token验证失败 - token长度: {len(token) if token else 0}")
            raise HTTPException(status_code=401, detail="无效的token")

        # 检查当前用户是否为管理员
        if payload.get("role") != "manager":
            raise HTTPException(status_code=403, detail="只有管理员可以新增用户")

        # 验证输入数据
        if not all([user_data.username, user_data.password, user_data.role, user_data.name, user_data.email]):
            raise HTTPException(status_code=400, detail="所有字段都是必填的")

        if user_data.role not in ["staff", "manager"]:
            raise HTTPException(status_code=400, detail="无效的角色")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查用户名是否已存在
        cursor.execute("SELECT id FROM lab_staff WHERE username = %s", (user_data.username,))
        existing_user = cursor.fetchone()
        if existing_user:
            conn.close()
            raise HTTPException(status_code=400, detail="用户名已存在")

        # 检查邮箱是否已被使用
        cursor.execute("SELECT id FROM lab_staff WHERE email = %s", (user_data.email,))
        existing_email = cursor.fetchone()
        if existing_email:
            conn.close()
            raise HTTPException(status_code=400, detail="邮箱已被使用")

        # 插入新用户
        insert_query = """
        INSERT INTO lab_staff (username, password, role, name, email, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, NOW(), NOW())
        """
        cursor.execute(insert_query, (
            user_data.username,
            user_data.password,
            user_data.role,
            user_data.name,
            user_data.email
        ))

        new_user_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "用户添加成功",
            "data": {
                "id": new_user_id,
                "username": user_data.username,
                "name": user_data.name,
                "email": user_data.email,
                "role": user_data.role
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"新增用户错误: {e}")
        import traceback
        print(f"错误详情: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/auth/add-user-simple")
async def add_user_simple(user_data: AddUserRequest):
    """新增用户（简化版，无需token验证）"""
    try:
        # 验证输入数据
        if not all([user_data.username, user_data.password, user_data.role, user_data.name, user_data.email]):
            raise HTTPException(status_code=400, detail="所有字段都是必填的")

        if user_data.role not in ["staff", "manager"]:
            raise HTTPException(status_code=400, detail="无效的角色")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查用户名是否已存在
        cursor.execute("SELECT id FROM lab_staff WHERE username = %s", (user_data.username,))
        existing_user = cursor.fetchone()
        if existing_user:
            conn.close()
            raise HTTPException(status_code=400, detail="用户名已存在")

        # 检查邮箱是否已被使用
        cursor.execute("SELECT id FROM lab_staff WHERE email = %s", (user_data.email,))
        existing_email = cursor.fetchone()
        if existing_email:
            conn.close()
            raise HTTPException(status_code=400, detail="邮箱已被使用")

        # 插入新用户
        insert_query = """
        INSERT INTO lab_staff (username, password, role, name, email, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, NOW(), NOW())
        """
        cursor.execute(insert_query, (
            user_data.username,
            user_data.password,
            user_data.role,
            user_data.name,
            user_data.email
        ))

        new_user_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "用户添加成功",
            "data": {
                "id": new_user_id,
                "username": user_data.username,
                "name": user_data.name,
                "email": user_data.email,
                "role": user_data.role
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"新增用户错误: {e}")
        import traceback
        print(f"错误详情: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")


@router.get("/api/auth/users")
async def get_all_users():
    """获取所有用户列表"""
    try:
        # 获取所有用户
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT id, username, password, role, name, email, created_at, updated_at FROM lab_staff ORDER BY created_at DESC"
        cursor.execute(query)
        users = cursor.fetchall()

        conn.close()

        return {
            "success": True,
            "data": users
        }

    except Exception as e:
        print(f"获取用户列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/auth/users/{user_id}")
async def delete_user(user_id: int):
    """删除用户"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查用户是否存在
        check_query = "SELECT id, username FROM lab_staff WHERE id = %s"
        cursor.execute(check_query, (user_id,))
        user = cursor.fetchone()

        if not user:
            conn.close()
            raise HTTPException(status_code=404, detail="用户不存在")

        # 删除用户
        delete_query = "DELETE FROM lab_staff WHERE id = %s"
        cursor.execute(delete_query, (user_id,))
        conn.commit()

        conn.close()

        return {
            "success": True,
            "message": f"用户 {user['username']} 删除成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除用户错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

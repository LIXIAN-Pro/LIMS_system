# routes/project_end.py
from fastapi import APIRouter, HTTPException
import database

router = APIRouter()

@router.get("/api/project-end/approved-reports")
async def get_approved_reports():
    """获取已通过审核的实验报告与编制报告列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 获取已通过三级审核的编制报告
        query = """
        SELECT eer.*, er.project_id, er.project_code, er.project_name, er.personnel_name as experiment_personnel_name,
               er.original_filename as experiment_report_filename,
               eer.original_filename as edit_report_filename,
               eer.upload_time as edit_upload_time,
               eer.reviewed_at as final_review_time
        FROM experiment_edit_reports eer
        LEFT JOIN experiment_reports er ON eer.experiment_report_id = er.id
        WHERE eer.review_level = 3 AND eer.review_status = 'approved'
        ORDER BY eer.reviewed_at DESC
        """

        cursor.execute(query)
        approved_reports = cursor.fetchall()

        conn.close()

        return {"success": True, "data": approved_reports}

    except Exception as e:
        print(f"获取已通过审核报告列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

# routes/tasks.py
from fastapi import APIRouter, HTTPException, Query  # 添加 Query 导入
from datetime import datetime, timedelta  # 如果需要 timedelta

from fastapi import APIRouter, HTTPException
import database
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel

router = APIRouter()

# 数据模型
class TaskCreate(BaseModel):
    project_id: int
    start_time: datetime
    end_time: datetime
    equipment_id: Optional[int] = None
    agentia_id: Optional[int] = None
    template_id: Optional[int] = None
    collector_ids: List[int]

class TaskResponse(BaseModel):
    id: int
    task_code: str
    project_id: int
    project_code: str
    status: str
    start_time: datetime
    end_time: datetime
    created_at: datetime

def generate_task_code():
    """生成任务编号：TASK-YYMMDD-序列号"""
    date_str = datetime.now().strftime('%y%m%d')
    
    conn = database.get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 查询或创建当日序列
        query = "SELECT sequence FROM task_sequences WHERE date_prefix = %s FOR UPDATE"
        cursor.execute(query, (date_str,))
        result = cursor.fetchone()
        
        if result:
            sequence = result['sequence'] + 1
            update_query = "UPDATE task_sequences SET sequence = %s WHERE date_prefix = %s"
            cursor.execute(update_query, (sequence, date_str))
        else:
            sequence = 1
            insert_query = "INSERT INTO task_sequences (date_prefix, sequence, created_at) VALUES (%s, %s, %s)"
            cursor.execute(insert_query, (date_str, sequence, datetime.now().date()))
        
        conn.commit()
        
        return f"TASK-{date_str}-{sequence:03d}"
        
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()

@router.get("/api/tasks/available-projects")
async def get_available_projects():
    """获取可用的项目（未完成的项目且未下发任务或任务被取消，不包含送样项目，且项目没有已完成的任务）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT p.*, e.unit_name as entrust_unit_name
        FROM projects p
        LEFT JOIN entrust_units e ON p.entrust_unit_id = e.id
        WHERE p.status IN ('planning', 'in_progress')
        AND NOT p.project_code LIKE 'HFCMSY%'
        AND (
            p.id NOT IN (SELECT DISTINCT project_id FROM tasks)
            OR NOT EXISTS (
                SELECT 1 FROM tasks t
                WHERE t.project_id = p.id
                AND t.status IN ('pending', 'in_progress')
            )
        )
        AND NOT EXISTS (
            SELECT 1 FROM tasks t
            WHERE t.project_id = p.id
            AND t.status = 'completed'
        )
        ORDER BY p.created_at DESC
        """
        cursor.execute(query)
        projects = cursor.fetchall()

        conn.close()
        return {"success": True, "data": projects}

    except Exception as e:
        print(f"获取可用项目错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/total-projects-count")
async def get_total_projects_count():
    """获取总项目数（不包含送样项目）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT COUNT(*) as total_count
        FROM projects
        WHERE NOT project_code LIKE 'HFCMSY%'
        """
        cursor.execute(query)
        result = cursor.fetchone()

        conn.close()
        return {"success": True, "data": {"total_projects": result['total_count']}}

    except Exception as e:
        print(f"获取总项目数错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/available-collectors")
async def get_available_collectors():
    """获取可用的采集人员（状态为active）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM collectors WHERE status = 'active' ORDER BY name"
        cursor.execute(query)
        collectors = cursor.fetchall()
        
        conn.close()
        return {"success": True, "data": collectors}
        
    except Exception as e:
        print(f"获取可用采集人员错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/available-equipment")
async def get_available_equipment():
    """获取可用的设备（状态为空闲）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM equipment WHERE status = 'idle' ORDER BY name"
        cursor.execute(query)
        equipment = cursor.fetchall()
        
        conn.close()
        return {"success": True, "data": equipment}
        
    except Exception as e:
        print(f"获取可用设备错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/available-agentia")
async def get_available_agentia():
    """获取可用的试剂（有库存且状态可用）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        query = """
        SELECT * FROM agentia 
        WHERE quantity > 0 AND status != 'out_of_stock'
        ORDER BY name
        """
        cursor.execute(query)
        agentia = cursor.fetchall()
        
        conn.close()
        return {"success": True, "data": agentia}
        
    except Exception as e:
        print(f"获取可用试剂错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/assigned-project-ids")
async def get_assigned_project_ids():
    """获取已下发任务的项目ID列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT DISTINCT project_id FROM tasks"
        cursor.execute(query)
        result = cursor.fetchall()

        conn.close()
        project_ids = [row['project_id'] for row in result]
        return {"success": True, "data": project_ids}

    except Exception as e:
        print(f"获取已分配项目ID错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/tasks")
async def create_task(task_data: TaskCreate):
    """创建新任务"""
    conn = None
    try:
        # 验证采集人员数量
        if len(task_data.collector_ids) < 2 or len(task_data.collector_ids) > 4:
            raise HTTPException(status_code=400, detail="必须选择至少两位，最多四位采集人员")
        
        # 验证时间
        if task_data.start_time >= task_data.end_time:
            raise HTTPException(status_code=400, detail="开始时间必须早于结束时间")
        
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 验证项目是否存在
        cursor.execute("SELECT id, project_code FROM projects WHERE id = %s", (task_data.project_id,))
        project = cursor.fetchone()
        if not project:
            raise HTTPException(status_code=404, detail="项目不存在")
        
        # 验证采集人员是否存在且可用
        collectors_info = []
        for collector_id in task_data.collector_ids:
            cursor.execute("SELECT id, name, employee_id FROM collectors WHERE id = %s AND status = 'active'", (collector_id,))
            collector = cursor.fetchone()
            if not collector:
                raise HTTPException(status_code=404, detail=f"采集人员ID {collector_id} 不存在或不可用")
            collectors_info.append(collector)
        
        # 验证设备（如果选择了）
        equipment_info = None
        if task_data.equipment_id:
            cursor.execute("SELECT id, equipment_code FROM equipment WHERE id = %s AND status = 'idle'", (task_data.equipment_id,))
            equipment_info = cursor.fetchone()
            if not equipment_info:
                raise HTTPException(status_code=404, detail="设备不存在或已被占用")
        
        # 验证试剂（如果选择了）
        agentia_info = None
        if task_data.agentia_id:
            cursor.execute("SELECT id, agentia_code, quantity FROM agentia WHERE id = %s", (task_data.agentia_id,))
            agentia_info = cursor.fetchone()
            if not agentia_info:
                raise HTTPException(status_code=404, detail="试剂不存在")
            if agentia_info['quantity'] <= 0:
                raise HTTPException(status_code=400, detail="试剂库存不足")
        
        # 验证表单（如果选择了）
        template_info = None
        if task_data.template_id:
            cursor.execute("SELECT id FROM collection_templates WHERE id = %s", (task_data.template_id,))
            template_info = cursor.fetchone()
            if not template_info:
                raise HTTPException(status_code=404, detail="表单模板不存在")
        
        # 生成任务编号：项目编号 + 任务序列号
        # 查询该项目已有的任务数量
        cursor.execute("SELECT COUNT(*) as task_count FROM tasks WHERE project_id = %s", (task_data.project_id,))
        task_count_result = cursor.fetchone()
        task_sequence = task_count_result['task_count'] + 1

        # 生成任务编号：HFCM2601001-1, HFCM2601001-2 等
        task_code = f"{project['project_code']}-{task_sequence}"
        
        # 开始事务
        cursor.execute("START TRANSACTION")
        
        try:
            # 1. 插入任务记录（去除冗余的 equipment_code / agentia_code 字段）
            insert_task_query = """
            INSERT INTO tasks
            (task_code, project_id, project_code, start_time, end_time,
             equipment_id, agentia_id, template_id, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'in_progress')
            """

            cursor.execute(insert_task_query, (
                task_code,
                task_data.project_id,
                project['project_code'],
                task_data.start_time,
                task_data.end_time,
                task_data.equipment_id,
                task_data.agentia_id,
                task_data.template_id
            ))
            
            task_id = cursor.lastrowid
            
            # 2. 插入采集人员关联
            for collector in collectors_info:
                insert_collector_query = """
                INSERT INTO task_collectors 
                (task_id, collector_id, collector_name, collector_employee_id)
                VALUES (%s, %s, %s, %s)
                """
                cursor.execute(insert_collector_query, (
                    task_id,
                    collector['id'],
                    collector['name'],
                    collector['employee_id']
                ))
            
            # 3. 更新设备状态（如果选择了设备）
            if task_data.equipment_id:
                cursor.execute(
                    "UPDATE equipment SET status = 'in_use' WHERE id = %s",
                    (task_data.equipment_id,)
                )
            
            # 4. 更新试剂库存（如果选择了试剂）
            if task_data.agentia_id:
                # 减少库存
                cursor.execute(
                    "UPDATE agentia SET quantity = quantity - 1 WHERE id = %s",
                    (task_data.agentia_id,)
                )
                
                # 检查并更新试剂状态
                cursor.execute("""
                    UPDATE agentia 
                    SET status = CASE 
                        WHEN quantity = 0 THEN 'out_of_stock'
                        WHEN quantity <= 5 THEN 'low_stock'
                        ELSE 'available'
                    END
                    WHERE id = %s
                """, (task_data.agentia_id,))
            
            # 提交事务
            conn.commit()
            
            # 获取刚创建的任务
            cursor.execute("SELECT * FROM tasks WHERE id = %s", (task_id,))
            new_task = cursor.fetchone()
            
            return {
                "success": True,
                "message": "任务下发成功",
                "data": new_task,
                "task_code": task_code
            }
            
        except Exception as e:
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"创建任务失败: {str(e)}")
        
    except HTTPException:
        raise
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"创建任务错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
    finally:
        if conn:
            conn.close()









# ============ 以下是新增的进行中任务API接口 ============

@router.get("/api/tasks")
async def get_tasks(
    page: int = Query(1, ge=1),
    page_size: int = Query(6, ge=1, le=50),
    search: str = Query(None),
    # status: str = Query(None),
    date_range: str = Query(None),
    start_date: str = Query(None),
    end_date: str = Query(None)
):
    """获取任务列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 构建基础查询
        base_query = """
        SELECT
            t.*,
            p.project_name,
            e.name as equipment_name,
            e.equipment_code,
            a.name as agentia_name,
            a.agentia_code,
            ct.file_name as template_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN equipment e ON t.equipment_id = e.id
        LEFT JOIN agentia a ON t.agentia_id = a.id
        LEFT JOIN collection_templates ct ON t.template_id = ct.id
        WHERE t.status != 'completed'
        """

        count_query = """
        SELECT COUNT(*) as total
        FROM tasks t
        WHERE t.status != 'completed'
        """
        
        params = []
        count_params = []
        
        # 搜索条件
        if search:
            base_query += """
            AND (t.task_code LIKE %s OR t.project_code LIKE %s OR p.project_name LIKE %s OR
                 EXISTS (SELECT 1 FROM task_collectors tc JOIN collectors c ON tc.collector_id = c.id
                        WHERE tc.task_id = t.id AND c.name LIKE %s))
            """
            count_query += """
            AND (t.task_code LIKE %s OR t.project_code LIKE %s OR
                 EXISTS (SELECT 1 FROM projects p WHERE p.id = t.project_id AND p.project_name LIKE %s) OR
                 EXISTS (SELECT 1 FROM task_collectors tc JOIN collectors c ON tc.collector_id = c.id
                        WHERE tc.task_id = t.id AND c.name LIKE %s))
            """
            search_pattern = f"%{search}%"
            params.extend([search_pattern, search_pattern, search_pattern, search_pattern])
            count_params.extend([search_pattern, search_pattern, search_pattern, search_pattern])
        
        # 状态筛选
        # if status:
        #     base_query += " AND t.status = %s"
        #     count_query += " AND t.status = %s"
        #     params.append(status)
        #     count_params.append(status)
        
        # 日期范围筛选
        if date_range:
            if date_range == 'today':
                base_query += " AND DATE(t.created_at) = CURDATE()"
                count_query += " AND DATE(t.created_at) = CURDATE()"
            elif date_range == 'week':
                base_query += " AND YEARWEEK(t.created_at, 1) = YEARWEEK(CURDATE(), 1)"
                count_query += " AND YEARWEEK(t.created_at, 1) = YEARWEEK(CURDATE(), 1)"
            elif date_range == 'month':
                base_query += " AND MONTH(t.created_at) = MONTH(CURDATE()) AND YEAR(t.created_at) = YEAR(CURDATE())"
                count_query += " AND MONTH(t.created_at) = MONTH(CURDATE()) AND YEAR(t.created_at) = YEAR(CURDATE())"
            elif date_range == 'custom' and start_date and end_date:
                base_query += " AND DATE(t.created_at) BETWEEN %s AND %s"
                count_query += " AND DATE(t.created_at) BETWEEN %s AND %s"
                params.extend([start_date, end_date])
                count_params.extend([start_date, end_date])
        
        # 排序和分页：取消任务排在后面
        base_query += """
        ORDER BY
            CASE
                WHEN t.status = 'in_progress' THEN 1
                WHEN t.status = 'pending' THEN 2
                WHEN t.status = 'cancelled' THEN 3
                ELSE 4
            END,
            t.created_at DESC
        LIMIT %s OFFSET %s
        """
        offset = (page - 1) * page_size
        params.extend([page_size, offset])
        
        # 执行查询
        cursor.execute(base_query, params)
        tasks = cursor.fetchall()
        
        # 获取总数量
        cursor.execute(count_query, count_params)
        total_result = cursor.fetchone()
        total = total_result['total'] if total_result else 0
        
        # 为每个任务获取采集人员
        for task in tasks:
            cursor.execute("""
            SELECT c.* 
            FROM task_collectors tc
            JOIN collectors c ON tc.collector_id = c.id
            WHERE tc.task_id = %s
            """, (task['id'],))
            collectors = cursor.fetchall()
            task['collectors'] = collectors
        
        # 获取统计信息
        cursor.execute("""
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
        FROM tasks
        """)
        stats = cursor.fetchone()
        
        conn.close()
        
        return {
            "success": True,
            "data": {
                "tasks": tasks,
                "total": total,
                "page": page,
                "page_size": page_size,
                "total_pages": (total + page_size - 1) // page_size,
                "stats": stats
            }
        }
        
    except Exception as e:
        print(f"获取任务列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/completed")
async def get_completed_tasks(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=50),
    search: str = Query(None),
    date_range: str = Query(None),
    start_date: str = Query(None),
    end_date: str = Query(None)
):
    """获取已完成任务列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 构建基础查询 - 只获取已完成的任务
        base_query = """
        SELECT
            t.*,
            p.project_name,
            p.sample_status,
            e.name as equipment_name,
            e.equipment_code,
            a.name as agentia_name,
            a.agentia_code,
            ct.file_name as template_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN equipment e ON t.equipment_id = e.id
        LEFT JOIN agentia a ON t.agentia_id = a.id
        LEFT JOIN collection_templates ct ON t.template_id = ct.id
        WHERE t.status = 'completed'
        """

        count_query = """
        SELECT COUNT(*) as total
        FROM tasks t
        WHERE t.status = 'completed'
        """

        params = []
        count_params = []

        # 搜索条件
        if search:
            base_query += """
            AND (t.task_code LIKE %s OR t.project_code LIKE %s OR p.project_name LIKE %s OR
                 EXISTS (SELECT 1 FROM task_collectors tc JOIN collectors c ON tc.collector_id = c.id
                        WHERE tc.task_id = t.id AND c.name LIKE %s))
            """
            count_query += """
            AND (t.task_code LIKE %s OR t.project_code LIKE %s OR
                 EXISTS (SELECT 1 FROM projects p WHERE p.id = t.project_id AND p.project_name LIKE %s) OR
                 EXISTS (SELECT 1 FROM task_collectors tc JOIN collectors c ON tc.collector_id = c.id
                        WHERE tc.task_id = t.id AND c.name LIKE %s))
            """
            search_pattern = f"%{search}%"
            params.extend([search_pattern, search_pattern, search_pattern, search_pattern])
            count_params.extend([search_pattern, search_pattern, search_pattern, search_pattern])

        # 日期范围筛选
        if date_range:
            if date_range == 'today':
                base_query += " AND DATE(t.updated_at) = CURDATE()"
                count_query += " AND DATE(t.updated_at) = CURDATE()"
            elif date_range == 'week':
                base_query += " AND YEARWEEK(t.updated_at, 1) = YEARWEEK(CURDATE(), 1)"
                count_query += " AND YEARWEEK(t.updated_at, 1) = YEARWEEK(CURDATE(), 1)"
            elif date_range == 'month':
                base_query += " AND MONTH(t.updated_at) = MONTH(CURDATE()) AND YEAR(t.updated_at) = YEAR(CURDATE())"
                count_query += " AND MONTH(t.updated_at) = MONTH(CURDATE()) AND YEAR(t.updated_at) = YEAR(CURDATE())"
            elif date_range == 'custom' and start_date and end_date:
                base_query += " AND DATE(t.updated_at) BETWEEN %s AND %s"
                count_query += " AND DATE(t.updated_at) BETWEEN %s AND %s"
                params.extend([start_date, end_date])
                count_params.extend([start_date, end_date])

        # 排序和分页 - 按完成时间倒序
        base_query += " ORDER BY t.updated_at DESC LIMIT %s OFFSET %s"
        offset = (page - 1) * page_size
        params.extend([page_size, offset])

        # 执行查询
        cursor.execute(base_query, params)
        tasks = cursor.fetchall()

        # 获取总数量
        cursor.execute(count_query, count_params)
        total_result = cursor.fetchone()
        total = total_result['total'] if total_result else 0

        # 为每个任务获取采集人员和提交的文件
        for task in tasks:
            # 获取采集人员
            cursor.execute("""
            SELECT c.*
            FROM task_collectors tc
            JOIN collectors c ON tc.collector_id = c.id
            WHERE tc.task_id = %s
            """, (task['id'],))
            collectors = cursor.fetchall()
            task['collectors'] = collectors

            # 获取提交的文件（包含提交者信息）
            cursor.execute("""
            SELECT s.id, s.file_name, s.file_size, s.upload_time,
                   COALESCE(ls.name, ls.username, '未知用户') as submitter_name
            FROM submit s
            LEFT JOIN lab_staff ls ON s.submitter_id = ls.id
            WHERE s.task_id = %s
            ORDER BY s.upload_time DESC
            """, (task['id'],))
            submitted_files = cursor.fetchall()
            task['submitted_files'] = submitted_files

        # 获取统计信息
        cursor.execute("""
        SELECT COUNT(*) as total_completed
        FROM tasks
        WHERE status = 'completed'
        """)
        stats = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "data": {
                "tasks": tasks,
                "total": total,
                "page": page,
                "page_size": page_size,
                "total_pages": (total + page_size - 1) // page_size,
                "stats": stats
            }
        }

    except Exception as e:
        print(f"获取已完成任务列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/project/{project_id}/submitted-files")
async def get_project_submitted_files(project_id: int):
    """获取项目已完成任务的提交文件列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 获取项目已完成任务的提交文件
        query = """
        SELECT s.id, s.file_name, s.file_size, s.upload_time,
               COALESCE(ls.name, ls.username, '未知用户') as submitter_name
        FROM submit s
        LEFT JOIN lab_staff ls ON s.submitter_id = ls.id
        WHERE s.task_id IN (
            SELECT id FROM tasks WHERE project_id = %s AND status = 'completed'
        )
        ORDER BY s.upload_time DESC
        """
        cursor.execute(query, (project_id,))
        files = cursor.fetchall()

        conn.close()

        return {"success": True, "data": files}

    except Exception as e:
        print(f"获取项目提交文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/stats")
async def get_task_stats():
    """获取任务统计信息"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
        SELECT
            COUNT(*) as total,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
        FROM tasks
        """)

        stats = cursor.fetchone()
        conn.close()

        return {"success": True, "data": stats}

    except Exception as e:
        print(f"获取任务统计错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/tasks/{task_id}/start")
async def start_task(task_id: int):
    """开始任务"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 检查任务是否存在且状态为pending
        cursor.execute("SELECT status FROM tasks WHERE id = %s", (task_id,))
        task = cursor.fetchone()
        
        if not task:
            conn.close()
            raise HTTPException(status_code=404, detail="任务不存在")
        
        if task['status'] != 'pending':
            conn.close()
            raise HTTPException(status_code=400, detail="只有待开始的任务才能开始")
        
        # 更新任务状态
        cursor.execute("""
        UPDATE tasks 
        SET status = 'in_progress', updated_at = NOW() 
        WHERE id = %s
        """, (task_id,))
        
        conn.commit()
        conn.close()
        
        return {"success": True, "message": "任务已开始"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"开始任务错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/tasks/{task_id}/complete")
async def complete_task(task_id: int):
    """完成任务"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 检查任务是否存在且状态为in_progress
        cursor.execute("SELECT status FROM tasks WHERE id = %s", (task_id,))
        task = cursor.fetchone()
        
        if not task:
            conn.close()
            raise HTTPException(status_code=404, detail="任务不存在")
        
        if task['status'] != 'in_progress':
            conn.close()
            raise HTTPException(status_code=400, detail="只有进行中的任务才能完成")
        
        # 获取任务信息（包含项目信息）
        cursor.execute("SELECT project_code, equipment_id FROM tasks WHERE id = %s", (task_id,))
        task_info = cursor.fetchone()

        # 更新任务状态
        cursor.execute("""
        UPDATE tasks
        SET status = 'completed', updated_at = NOW()
        WHERE id = %s
        """, (task_id,))

        # 只释放当前任务自己绑定的设备，不影响同项目其他任务
        if task_info and task_info['equipment_id']:
            cursor.execute(
                "UPDATE equipment SET status = 'idle' WHERE id = %s",
                (task_info['equipment_id'],)
            )
        
        conn.commit()
        conn.close()
        
        return {"success": True, "message": "任务已完成"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"完成任务错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/tasks/{task_id}/cancel")
async def cancel_task(task_id: int):
    """取消任务"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()
        
        # 检查任务是否存在且状态不是completed
        cursor.execute("SELECT status, equipment_id, agentia_id FROM tasks WHERE id = %s", (task_id,))
        task = cursor.fetchone()
        
        if not task:
            conn.close()
            raise HTTPException(status_code=404, detail="任务不存在")
        
        if task['status'] in ['completed', 'cancelled']:
            conn.close()
            raise HTTPException(status_code=400, detail="已完成或已取消的任务不能再次取消")
        
        # 更新任务状态
        cursor.execute("""
        UPDATE tasks 
        SET status = 'cancelled', updated_at = NOW() 
        WHERE id = %s
        """, (task_id,))
        
        # 释放设备（如果有关联设备）
        if task['equipment_id']:
            cursor.execute("""
            UPDATE equipment 
            SET status = 'idle' 
            WHERE id = %s
            """, (task['equipment_id'],))
        
        # 恢复试剂库存（如果有关联试剂）
        if task['agentia_id']:
            cursor.execute("""
            UPDATE agentia
            SET quantity = quantity + 1,
                status = CASE
                    WHEN quantity + 1 > 5  THEN 'available'
                    WHEN quantity + 1 > 0  THEN 'low_stock'
                    ELSE 'out_of_stock'
                END
            WHERE id = %s
            """, (task['agentia_id'],))
        
        conn.commit()
        conn.close()

        return {"success": True, "message": "任务已取消"}

    except HTTPException:
        raise
    except Exception as e:
        print(f"取消任务错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/tasks/{task_id}")
async def delete_task(task_id: int):
    """删除任务 - 同时释放关联的设备、试剂和采集人员"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查任务是否存在
        cursor.execute("SELECT id, status, equipment_id, agentia_id FROM tasks WHERE id = %s", (task_id,))
        task = cursor.fetchone()

        if not task:
            conn.close()
            raise HTTPException(status_code=404, detail="任务不存在")

        # 只有已完成或已取消的任务才能删除
        if task['status'] not in ['completed', 'cancelled']:
            conn.close()
            raise HTTPException(
                status_code=400,
                detail=f"只有已完成或已取消的任务才能删除。当前任务状态：{task['status']}"
            )

        # 开始事务
        cursor.execute("START TRANSACTION")

        try:
            # 1. 释放设备（如果有关联的设备）
            if task['equipment_id']:
                cursor.execute(
                    "UPDATE equipment SET status = 'idle' WHERE id = %s",
                    (task['equipment_id'],)
                )

            # 2. 恢复试剂库存（如果有关联的试剂）
            if task['agentia_id']:
                cursor.execute("""
                    UPDATE agentia
                    SET quantity = quantity + 1,
                        status = CASE
                            WHEN quantity + 1 > 5 THEN 'available'
                            WHEN quantity + 1 > 0 THEN 'low_stock'
                            ELSE 'out_of_stock'
                        END
                    WHERE id = %s
                """, (task['agentia_id'],))

            # 3. 删除关联的提交文件（先获取文件路径以删除物理文件）
            cursor.execute("SELECT id, file_path FROM submit WHERE task_id = %s", (task_id,))
            submitted_files = cursor.fetchall()

            for file_record in submitted_files:
                # 删除物理文件（如果存在）
                if file_record['file_path']:
                    try:
                        import os
                        if os.path.exists(file_record['file_path']):
                            os.remove(file_record['file_path'])
                    except Exception as file_error:
                        print(f"删除物理文件失败: {file_error}")

            # 删除提交文件数据库记录
            cursor.execute("DELETE FROM submit WHERE task_id = %s", (task_id,))

            # 4. 删除任务采集人员关联记录
            cursor.execute("DELETE FROM task_collectors WHERE task_id = %s", (task_id,))

            # 5. 删除任务记录
            cursor.execute("DELETE FROM tasks WHERE id = %s", (task_id,))

            # 提交事务
            conn.commit()

            # 返回删除详情
            released_resources = []
            if task['equipment_id']:
                released_resources.append("设备")
            if task['agentia_id']:
                released_resources.append("试剂")
            if submitted_files:
                released_resources.append(f"{len(submitted_files)}个提交文件")

            resource_info = "，已释放" + "、".join(released_resources) if released_resources else ""

            conn.close()

            return {
                "success": True,
                "message": f"任务删除成功{resource_info}"
            }

        except Exception as tx_error:
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"删除任务事务失败: {str(tx_error)}")

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除任务错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
from fastapi import APIRouter, HTTPException
import database
from models import EntrustUnitCreate, EntrustUnitUpdate

router = APIRouter()

@router.get("/api/entrust-units")
async def get_entrust_units():
    """获取所有委托单位"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM entrust_units ORDER BY created_at DESC"
        cursor.execute(query)
        units = cursor.fetchall()

        conn.close()

        return {"success": True, "data": units}

    except Exception as e:
        print(f"获取委托单位列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/entrust-units/{unit_id}")
async def get_entrust_unit_by_id(unit_id: int):
    """获取单个委托单位"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM entrust_units WHERE id = %s"
        cursor.execute(query, (unit_id,))
        unit = cursor.fetchone()

        conn.close()

        if unit:
            return {"success": True, "data": unit}
        else:
            raise HTTPException(status_code=404, detail="委托单位不存在")

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取委托单位错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/entrust-units")
async def create_entrust_unit(unit: EntrustUnitCreate):
    """创建委托单位"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查电话号码是否已存在
        check_query = "SELECT id FROM entrust_units WHERE phone = %s"
        cursor.execute(check_query, (unit.phone,))
        existing = cursor.fetchone()

        if existing:
            conn.close()
            raise HTTPException(status_code=400, detail="联系电话已存在")

        # 插入新记录
        insert_query = """
        INSERT INTO entrust_units
        (unit_name, contact_person, phone, email, province, city, address, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """

        cursor.execute(insert_query, (
            unit.unit_name,
            unit.contact_person,
            unit.phone,
            unit.email,
            unit.province,
            unit.city,
            unit.address,
            unit.status
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = "SELECT * FROM entrust_units WHERE id = LAST_INSERT_ID()"
        cursor.execute(get_query)
        new_unit = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "委托单位创建成功",
            "data": new_unit
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"创建委托单位错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/entrust-units/{unit_id}")
async def update_entrust_unit(unit_id: int, unit: EntrustUnitUpdate):
    """更新委托单位"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM entrust_units WHERE id = %s"
        cursor.execute(check_query, (unit_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="委托单位不存在")

        # 检查电话号码是否与其他记录冲突
        check_phone = """
        SELECT id FROM entrust_units WHERE phone = %s AND id != %s
        """
        cursor.execute(check_phone, (unit.phone, unit_id))
        conflict = cursor.fetchone()

        if conflict:
            conn.close()
            raise HTTPException(status_code=400, detail="联系电话已被其他单位使用")

        # 更新记录
        update_query = """
        UPDATE entrust_units
        SET unit_name = %s, contact_person = %s, phone = %s,
            email = %s, province = %s, city = %s, address = %s, status = %s,
            updated_at = NOW()
        WHERE id = %s
        """

        cursor.execute(update_query, (
            unit.unit_name,
            unit.contact_person,
            unit.phone,
            unit.email,
            unit.province,
            unit.city,
            unit.address,
            unit.status,
            unit_id
        ))

        conn.commit()

        # 获取更新后的记录
        get_query = "SELECT * FROM entrust_units WHERE id = %s"
        cursor.execute(get_query, (unit_id,))
        updated_unit = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "委托单位更新成功",
            "data": updated_unit
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新委托单位错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/entrust-units/{unit_id}")
async def delete_entrust_unit(unit_id: int):
    """删除委托单位 - 同时清理关联资源"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id, unit_name FROM entrust_units WHERE id = %s"
        cursor.execute(check_query, (unit_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="委托单位不存在")

        unit_name = existing['unit_name']

        # 获取该委托单位的所有关联项目
        cursor.execute(
            "SELECT id, project_code FROM projects WHERE entrust_unit_id = %s",
            (unit_id,)
        )
        projects = cursor.fetchall()

        # 开启事务
        cursor.execute("START TRANSACTION")

        try:
            released_resources = {
                'equipment': 0,
                'agentia': 0,
                'files': 0,
                'projects': 0,
                'tasks': 0
            }

            # 处理每个关联项目
            for project in projects:
                project_id = project['id']
                released_resources['projects'] += 1

                # 获取该项目的所有任务
                cursor.execute(
                    "SELECT id, equipment_id, agentia_id FROM tasks WHERE project_id = %s",
                    (project_id,)
                )
                tasks = cursor.fetchall()
                released_resources['tasks'] += len(tasks)

                # 处理每个任务
                for task in tasks:
                    task_id = task['id']

                    # 1. 释放设备（如果有关联）
                    if task['equipment_id']:
                        cursor.execute(
                            "UPDATE equipment SET status = 'idle' WHERE id = %s",
                            (task['equipment_id'],)
                        )
                        released_resources['equipment'] += 1

                    # 2. 恢复试剂库存（如果有关联）
                    if task['agentia_id']:
                        cursor.execute("""
                            UPDATE agentia
                            SET quantity = quantity + 1,
                                status = CASE
                                    WHEN quantity + 1 > 5 THEN 'available'
                                    WHEN quantity + 1 > 0 THEN 'low_stock'
                                    ELSE 'out_of_stock'
                                END
                            WHERE id = %s
                        """, (task['agentia_id'],))
                        released_resources['agentia'] += 1

                    # 3. 删除提交文件（先获取文件路径）
                    cursor.execute(
                        "SELECT id, file_path FROM submit WHERE task_id = %s",
                        (task_id,)
                    )
                    submitted_files = cursor.fetchall()
                    released_resources['files'] += len(submitted_files)

                    for file_record in submitted_files:
                        if file_record['file_path']:
                            try:
                                import os
                                if os.path.exists(file_record['file_path']):
                                    os.remove(file_record['file_path'])
                            except Exception as file_error:
                                print(f"删除物理文件失败: {file_error}")

                    # 4. 删除提交文件数据库记录
                    cursor.execute("DELETE FROM submit WHERE task_id = %s", (task_id,))

                    # 5. 删除任务采集人员关联
                    cursor.execute("DELETE FROM task_collectors WHERE task_id = %s", (task_id,))

                # 删除任务记录
                cursor.execute("DELETE FROM tasks WHERE project_id = %s", (project_id,))

                # 删除样品记录（会级联删除关联数据）
                cursor.execute("DELETE FROM sample WHERE project_id = %s", (project_id,))

                # 删除实验报告（会级联删除关联数据）
                cursor.execute("DELETE FROM experiment_reports WHERE project_id = %s", (project_id,))

                # 删除项目记录
                cursor.execute("DELETE FROM projects WHERE id = %s", (project_id,))

            # 6. 删除委托单位
            cursor.execute("DELETE FROM entrust_units WHERE id = %s", (unit_id,))

            # 提交事务
            conn.commit()

            # 构建资源释放报告
            resource_details = []
            if released_resources['equipment'] > 0:
                resource_details.append(f"设备 {released_resources['equipment']} 台")
            if released_resources['agentia'] > 0:
                resource_details.append(f"试剂 {released_resources['agentia']} 份")
            if released_resources['files'] > 0:
                resource_details.append(f"文件 {released_resources['files']} 个")
            if released_resources['tasks'] > 0:
                resource_details.append(f"任务 {released_resources['tasks']} 条")
            if released_resources['projects'] > 0:
                resource_details.append(f"项目 {released_resources['projects']} 个")

            resource_info = "，已释放" + "、".join(resource_details) if resource_details else ""

            conn.close()

            return {
                "success": True,
                "message": f"委托单位「{unit_name}」删除成功{resource_info}"
            }

        except Exception as tx_error:
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"删除委托单位事务失败: {str(tx_error)}")

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除委托单位错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
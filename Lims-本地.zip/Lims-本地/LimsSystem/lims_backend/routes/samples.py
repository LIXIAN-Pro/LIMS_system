from fastapi import APIRouter, HTTPException
import database
from datetime import datetime
from models import SampleCreate, SampleUpdate, SampleEntryRequest

router = APIRouter()

@router.get("/api/samples")
async def get_samples(
    page: int = 1,
    page_size: int = 10,
    search: str = "",
    sample_type: str = "all"
):
    """获取样品列表"""
    try:
        print(f"[DEBUG] 获取样品列表 - 页码: {page}, 每页大小: {page_size}, 搜索: '{search}', 类型: '{sample_type}'")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 构建查询条件
        where_conditions = []
        params = []

        if search:
            where_conditions.append("(p.project_code LIKE %s OR p.project_name LIKE %s)")
            params.extend([f"%{search}%", f"%{search}%"])

        if sample_type != "all":
            where_conditions.append("s.sample_type = %s")
            params.append(sample_type)

        where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"
        print(f"[DEBUG] WHERE条件: {where_clause}, 参数: {params}")

        # 查询总数
        count_query = f"""
        SELECT COUNT(*) as total
        FROM sample s
        JOIN projects p ON s.project_id = p.id
        WHERE {where_clause}
        """
        cursor.execute(count_query, params)
        total_result = cursor.fetchone()
        total = total_result['total'] if total_result else 0

        # 查询样品数据
        offset = (page - 1) * page_size
        query = f"""
        SELECT
            s.id,
            s.project_id,
            s.sample_type,
            s.sample_code,
            s.entry_time,
            s.status,
            s.notes,
            s.created_at,
            p.project_code,
            p.project_name,
            p.collection_type as project_type,
            p.test_type,
            -- 只关联该项目最新一条已完成任务，避免多行重复
            t.start_time as collection_start_time,
            t.end_time as collection_end_time
        FROM sample s
        JOIN projects p ON s.project_id = p.id
        LEFT JOIN tasks t ON t.id = (
            SELECT id FROM tasks
            WHERE project_id = s.project_id AND status = 'completed'
            ORDER BY updated_at DESC LIMIT 1
        )
        WHERE {where_clause}
        ORDER BY s.entry_time DESC
        LIMIT %s OFFSET %s
        """
        print(f"[DEBUG] 执行查询: {query}")
        print(f"[DEBUG] 查询参数: {params + [page_size, offset]}")

        cursor.execute(query, params + [page_size, offset])
        samples_data = cursor.fetchall()
        print(f"[DEBUG] 查询到 {len(samples_data)} 条样品数据")

        # 处理数据 - 简化版本，先让基本功能工作
        samples = []
        for sample in samples_data:
            sample_dict = dict(sample)

            # 暂时简化采集人员信息处理
            # TODO: 后续优化采集人员查询
            if sample_dict['sample_type'] == 'collection':
                sample_dict['collectors'] = [{'name': '待完善'}]  # 临时占位符
            else:
                sample_dict['collectors'] = []

            samples.append(sample_dict)

        # 查询统计信息
        stats_query = """
        SELECT
            COUNT(*) as total_samples,
            SUM(CASE WHEN sample_type = 'collection' THEN 1 ELSE 0 END) as collection_samples,
            SUM(CASE WHEN sample_type = 'delivery' THEN 1 ELSE 0 END) as delivery_samples
        FROM sample
        """
        cursor.execute(stats_query)
        stats_result = cursor.fetchone()
        print(f"[DEBUG] 统计信息: {stats_result}")

        conn.close()

        print(f"[DEBUG] 返回数据 - 样品数量: {len(samples)}, 总计: {total}, 统计: {stats_result}")

        return {
            "success": True,
            "data": {
                "samples": samples,
                "total": total,
                "stats": {
                    "total_samples": stats_result['total_samples'] if stats_result and stats_result['total_samples'] is not None else 0,
                    "collection_samples": stats_result['collection_samples'] if stats_result and stats_result['collection_samples'] is not None else 0,
                    "delivery_samples": stats_result['delivery_samples'] if stats_result and stats_result['delivery_samples'] is not None else 0
                }
            }
        }

    except Exception as e:
        print(f"获取样品列表错误: {e}")
        import traceback
        print(f"错误详情: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/samples/enter")
async def enter_sample(sample_data: SampleEntryRequest):
    """样品入库"""
    try:
        project_id = sample_data.project_id
        sample_type = sample_data.sample_type

        if not project_id:
            raise HTTPException(status_code=400, detail="项目ID不能为空")

        if sample_type not in ['collection', 'delivery']:
            raise HTTPException(status_code=400, detail="样品类型无效")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查项目是否存在
        cursor.execute("SELECT id, sample_status FROM projects WHERE id = %s", (project_id,))
        project = cursor.fetchone()

        if not project:
            conn.close()
            raise HTTPException(status_code=404, detail="项目不存在")

        # 检查是否已经入库
        cursor.execute(
            "SELECT id FROM sample WHERE project_id = %s AND sample_type = %s",
            (project_id, sample_type)
        )
        existing_sample = cursor.fetchone()

        if existing_sample:
            conn.close()
            raise HTTPException(status_code=400, detail="该项目样品已入库")

        # 如果是采集样品，检查是否有完成的采集任务
        if sample_type == 'collection':
            cursor.execute("""
                SELECT COUNT(*) as task_count
                FROM tasks
                WHERE project_id = %s AND status = 'completed'
            """, (project_id,))
            task_result = cursor.fetchone()

            if not task_result or task_result['task_count'] == 0:
                conn.close()
                raise HTTPException(status_code=400, detail="该项目没有完成的采集任务，无法入库")

        # 生成样品编号
        cursor.execute("SELECT project_code FROM projects WHERE id = %s", (project_id,))
        project = cursor.fetchone()
        if not project:
            conn.close()
            raise HTTPException(status_code=404, detail="项目不存在")

        sample_code = f"YP-{project['project_code']}"

        # 检查样品编号是否已存在
        cursor.execute("SELECT id FROM sample WHERE sample_code = %s", (sample_code,))
        if cursor.fetchone():
            conn.close()
            raise HTTPException(status_code=400, detail="样品编号已存在")

        # 插入样品记录
        insert_query = """
        INSERT INTO sample (project_id, sample_type, sample_code, entry_time, status)
        VALUES (%s, %s, %s, NOW(), 'active')
        """
        try:
            cursor.execute(insert_query, (project_id, sample_type, sample_code))
        except Exception as e:
            conn.close()
            # 捕获唯一键约束冲突（并发重复入库）
            err_msg = str(e).lower()
            if 'duplicate' in err_msg or '1062' in err_msg:
                raise HTTPException(status_code=400, detail="该项目样品已入库（并发请求冲突），请刷新后重试。")
            raise HTTPException(status_code=500, detail=f"样品入库失败: {str(e)}")

        # 更新项目状态
        update_query = "UPDATE projects SET sample_status = 'entered', updated_at = NOW() WHERE id = %s"
        cursor.execute(update_query, (project_id,))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": f"样品入库成功 ({'采集样品' if sample_type == 'collection' else '送样样品'})"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"样品入库错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/samples/{sample_id}")
async def update_sample(sample_id: int, sample: SampleUpdate):
    """更新样品信息"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查样品是否存在
        cursor.execute("SELECT id FROM sample WHERE id = %s", (sample_id,))
        if not cursor.fetchone():
            conn.close()
            raise HTTPException(status_code=404, detail="样品不存在")

        # 构建更新语句
        update_fields = []
        params = []

        if sample.status is not None:
            update_fields.append("status = %s")
            params.append(sample.status)

        if sample.notes is not None:
            update_fields.append("notes = %s")
            params.append(sample.notes)

        if not update_fields:
            conn.close()
            raise HTTPException(status_code=400, detail="没有提供要更新的字段")

        update_query = f"""
        UPDATE sample
        SET {', '.join(update_fields)}, updated_at = NOW()
        WHERE id = %s
        """
        params.append(sample_id)

        cursor.execute(update_query, params)
        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "样品信息更新成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新样品信息错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/samples/stats")
async def get_sample_stats():
    """获取样品统计信息"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        stats_query = """
        SELECT
            COUNT(*) as total_samples,
            SUM(CASE WHEN sample_type = 'collection' THEN 1 ELSE 0 END) as collection_samples,
            SUM(CASE WHEN sample_type = 'delivery' THEN 1 ELSE 0 END) as delivery_samples
        FROM sample
        """
        cursor.execute(stats_query)
        stats_result = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "data": {
                "total_samples": stats_result['total_samples'] or 0,
                "collection_samples": stats_result['collection_samples'] or 0,
                "delivery_samples": stats_result['delivery_samples'] or 0
            }
        }

    except Exception as e:
        print(f"获取样品统计错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/samples")
async def create_sample(sample: SampleCreate):
    """创建样品记录"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查项目是否存在
        cursor.execute("SELECT id FROM projects WHERE id = %s", (sample.project_id,))
        if not cursor.fetchone():
            conn.close()
            raise HTTPException(status_code=404, detail="项目不存在")

        # 插入样品记录
        insert_query = """
        INSERT INTO sample (project_id, sample_type, entry_time, status, notes)
        VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (
            sample.project_id,
            sample.sample_type,
            sample.entry_time or datetime.now(),
            sample.status,
            sample.notes
        ))

        sample_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "样品创建成功",
            "data": {"id": sample_id}
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"创建样品错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/samples/{sample_id}")
async def delete_sample(sample_id: int):
    """删除样品记录 - 同时同步项目样品状态"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查样品是否存在
        cursor.execute("""
            SELECT s.id, s.project_id, s.sample_type, s.sample_code, p.project_code
            FROM sample s
            JOIN projects p ON s.project_id = p.id
            WHERE s.id = %s
        """, (sample_id,))
        sample = cursor.fetchone()

        if not sample:
            conn.close()
            raise HTTPException(status_code=404, detail="样品不存在")

        project_id = sample['project_id']
        sample_type = sample['sample_type']
        sample_code = sample['sample_code']

        # 开启事务
        cursor.execute("START TRANSACTION")

        try:
            # 删除样品记录
            cursor.execute("DELETE FROM sample WHERE id = %s", (sample_id,))

            # 检查该项目同类型是否还有其他样品
            cursor.execute("""
                SELECT COUNT(*) as cnt FROM sample
                WHERE project_id = %s AND sample_type = %s
            """, (project_id, sample_type))
            remaining_count = cursor.fetchone()['cnt']

            # 如果没有剩余样品，更新项目状态为待入库
            if remaining_count == 0:
                cursor.execute(
                    "UPDATE projects SET sample_status = 'pending', updated_at = NOW() WHERE id = %s",
                    (project_id,)
                )

            conn.commit()

            status_info = "" if remaining_count == 0 else f"，项目「{sample['project_code']}」仍有其他样品"

            conn.close()

            return {
                "success": True,
                "message": f"样品「{sample_code}」删除成功{status_info}，项目样品状态已更新"
            }

        except Exception as tx_error:
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"删除样品事务失败: {str(tx_error)}")

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除样品错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
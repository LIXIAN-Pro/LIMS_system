# routes/projects.py
from fastapi import APIRouter, HTTPException
import database
from models import ProjectCreate, ProjectUpdate
from datetime import datetime

router = APIRouter()

# 注意：这个路由必须在 /api/projects/{project_id} 之前定义，否则会被错误匹配
from fastapi import Query

@router.get("/api/next-sequence")
async def get_next_project_sequence(collection_type: str = Query(..., description="采集方式：采样或送样")):
    """获取下一个项目编号序列，用于生成项目编号"""
    try:
        # 验证采集方式参数
        if collection_type not in ["采样", "送样"]:
            raise HTTPException(status_code=400, detail="采集方式必须是'采样'或'送样'")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 获取当前日期的前缀 (YYMM 格式，年份后两位 + 月份)
        now = datetime.now()
        date_prefix = now.strftime('%y%m')  # YYMM 格式
        # print(date_prefix)

        # 确定前缀
        code_prefix = 'HFCMSY' if collection_type == '送样' else 'HFCM'

        # 查询当月该采集方式的最大编号
        query = """
        SELECT project_code
        FROM projects
        WHERE project_code LIKE %s AND collection_type = %s
        ORDER BY project_code DESC
        LIMIT 1
        """
        cursor.execute(query, (f"{code_prefix}{date_prefix}%", collection_type))
        result = cursor.fetchone()

        conn.close()

        next_sequence = 1  # 默认从001开始

        if result and result['project_code']:
            # 解析现有编号，提取序号部分
            project_code = result['project_code']
            try:
                # 新格式如：HFCM2601001 (采样) 或 HFCMSY2601001 (送样)
                # 序列号是最后三位数字，格式为001-999
                sequence_part = project_code[-3:]  # 获取最后三位
                current_sequence = int(sequence_part)
                next_sequence = current_sequence + 1
            except (ValueError, IndexError) as e:
                print(f"解析项目编号失败: {project_code}, 错误: {e}")
                # 如果解析失败，使用默认值

        # 检查序列号上限（每月最多1000个项目）
        if next_sequence > 999:
            raise HTTPException(status_code=400, detail=f"当月{collection_type}项目数量已达到上限（999个），无法生成更多项目编号")

        return {
            "success": True,
            "next_sequence": next_sequence,
            "message": f"获取{collection_type}下一个序列号成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取下一个序列号错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/projects/available")
async def get_available_projects():
    """获取可用于新项目生成的项目（未被下发任务或任务被取消的项目，且没有已完成任务）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT p.*, e.unit_name as entrust_unit_name
        FROM projects p
        LEFT JOIN entrust_units e ON p.entrust_unit_id = e.id
        WHERE p.status IN ('planning', 'in_progress')
        AND (
            p.id NOT IN (SELECT DISTINCT project_id FROM tasks)
            OR NOT EXISTS (
                SELECT 1 FROM tasks t
                WHERE t.project_id = p.id
                AND t.status IN ('pending', 'in_progress')
            )
        )
        AND NOT EXISTS (
            SELECT 1 FROM tasks t
            WHERE t.project_id = p.id
            AND t.status = 'completed'
        )
        AND NOT (
            p.collection_type = '送样'
            AND p.sample_status = 'entered'
        )
        ORDER BY p.created_at DESC
        """
        cursor.execute(query)
        projects = cursor.fetchall()

        conn.close()
        return {"success": True, "data": projects}

    except Exception as e:
        print(f"获取可用项目列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/projects")
async def get_projects():
    """获取所有项目列表（包含所有项目）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT p.*, e.unit_name as entrust_unit_name
        FROM projects p
        LEFT JOIN entrust_units e ON p.entrust_unit_id = e.id
        ORDER BY p.created_at DESC
        """
        cursor.execute(query)
        projects = cursor.fetchall()

        conn.close()
        return {"success": True, "data": projects}

    except Exception as e:
        print(f"获取项目列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/projects/{project_id}")
async def get_project_by_id(project_id: int):
    """获取单个项目"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT p.*, e.unit_name as entrust_unit_name 
        FROM projects p 
        LEFT JOIN entrust_units e ON p.entrust_unit_id = e.id 
        WHERE p.id = %s
        """
        cursor.execute(query, (project_id,))
        project = cursor.fetchone()

        conn.close()

        if project:
            return {"success": True, "data": project}
        else:
            raise HTTPException(status_code=404, detail="项目不存在")

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取项目错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/projects")
async def create_project(project: ProjectCreate):
    """创建项目"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查项目编号是否已存在
        check_query = "SELECT id FROM projects WHERE project_code = %s"
        cursor.execute(check_query, (project.project_code,))
        existing = cursor.fetchone()

        if existing:
            conn.close()
            raise HTTPException(status_code=400, detail="项目编号已存在")

        # 验证委托单位是否存在
        check_unit_query = "SELECT id FROM entrust_units WHERE id = %s"
        cursor.execute(check_unit_query, (project.entrust_unit_id,))
        unit_exists = cursor.fetchone()

        if not unit_exists:
            conn.close()
            raise HTTPException(status_code=400, detail="委托单位不存在")

        # 验证检测类型
        valid_test_types = ["废气", "废水", "颗粒", "噪声", "废气、废水", "废水、颗粒", "颗粒、废气", "废气、噪声", "废水、噪声", "废气、废水、噪声"]
        if project.test_type not in valid_test_types:
            conn.close()
            raise HTTPException(status_code=400, detail="检测类型无效")

        # 验证采集方式
        if project.collection_type not in ["采样", "送样"]:
            conn.close()
            raise HTTPException(status_code=400, detail="采集方式必须是'采样'或'送样'")

        # 验证项目状态
        if project.status not in ["planning", "in_progress", "completed"]:
            conn.close()
            raise HTTPException(status_code=400, detail="项目状态无效")

        # 插入新记录
        insert_query = """
        INSERT INTO projects 
        (project_code, project_name, entrust_unit_id, test_type, 
         collection_type, location, description, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """

        cursor.execute(insert_query, (
            project.project_code,
            project.project_name,
            project.entrust_unit_id,
            project.test_type,
            project.collection_type,
            project.location,
            project.description,
            project.status
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = """
        SELECT p.*, e.unit_name as entrust_unit_name 
        FROM projects p 
        LEFT JOIN entrust_units e ON p.entrust_unit_id = e.id 
        WHERE p.id = LAST_INSERT_ID()
        """
        cursor.execute(get_query)
        new_project = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "项目创建成功",
            "data": new_project
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"创建项目错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/projects/{project_id}")
async def update_project(project_id: int, project: ProjectUpdate):
    """更新项目信息"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM projects WHERE id = %s"
        cursor.execute(check_query, (project_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="项目不存在")

        # 检查项目编号是否与其他记录冲突
        check_project_code = """
        SELECT id FROM projects WHERE project_code = %s AND id != %s
        """
        cursor.execute(check_project_code, (project.project_code, project_id))
        conflict = cursor.fetchone()

        if conflict:
            conn.close()
            raise HTTPException(status_code=400, detail="项目编号已被其他项目使用")

        # 验证委托单位是否存在
        check_unit_query = "SELECT id FROM entrust_units WHERE id = %s"
        cursor.execute(check_unit_query, (project.entrust_unit_id,))
        unit_exists = cursor.fetchone()

        if not unit_exists:
            conn.close()
            raise HTTPException(status_code=400, detail="委托单位不存在")

        # 验证检测类型
        valid_test_types = ["废气", "废水", "颗粒", "噪声", "废气、废水", "废水、颗粒", "颗粒、废气", "废气、噪声", "废水、噪声", "废气、废水、噪声"]
        if project.test_type not in valid_test_types:
            conn.close()
            raise HTTPException(status_code=400, detail="检测类型无效")

        # 验证采集方式
        if project.collection_type not in ["采样", "送样"]:
            conn.close()
            raise HTTPException(status_code=400, detail="采集方式必须是'采样'或'送样'")

        # 验证项目状态
        if project.status not in ["planning", "in_progress", "completed"]:
            conn.close()
            raise HTTPException(status_code=400, detail="项目状态无效")

        # 状态机校验：限制非法状态跳转
        cursor.execute("SELECT status FROM projects WHERE id = %s", (project_id,))
        current = cursor.fetchone()
        if current:
            current_status = current['status']
            valid_transitions = {
                "planning":    ["planning", "in_progress"],
                "in_progress": ["in_progress", "completed"],
                "completed":   ["completed"],
            }
            allowed = valid_transitions.get(current_status, [])
            if project.status not in allowed:
                conn.close()
                raise HTTPException(
                    status_code=400,
                    detail=f"项目状态不能从「{current_status}」变更为「{project.status}」"
                )

        # 更新记录
        update_query = """
        UPDATE projects 
        SET project_code = %s, project_name = %s, entrust_unit_id = %s,
            test_type = %s, collection_type = %s, location = %s,
            description = %s, status = %s, updated_at = NOW()
        WHERE id = %s
        """

        cursor.execute(update_query, (
            project.project_code,
            project.project_name,
            project.entrust_unit_id,
            project.test_type,
            project.collection_type,
            project.location,
            project.description,
            project.status,
            project_id
        ))

        conn.commit()

        # 获取更新后的记录
        get_query = """
        SELECT p.*, e.unit_name as entrust_unit_name 
        FROM projects p 
        LEFT JOIN entrust_units e ON p.entrust_unit_id = e.id 
        WHERE p.id = %s
        """
        cursor.execute(get_query, (project_id,))
        updated_project = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "项目更新成功",
            "data": updated_project
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新项目错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/projects/{project_id}")
async def delete_project(project_id: int):
    """删除项目"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM projects WHERE id = %s"
        cursor.execute(check_query, (project_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="项目不存在")

        try:
            # 按正确顺序删除子表数据，避免外键约束冲突
            # 1. 删除任务的提交文件记录
            cursor.execute("""
                DELETE FROM submit
                WHERE task_id IN (SELECT id FROM tasks WHERE project_id = %s)
            """, (project_id,))

            # 2. 删除任务的采集人员关联记录
            cursor.execute("""
                DELETE FROM task_collectors
                WHERE task_id IN (SELECT id FROM tasks WHERE project_id = %s)
            """, (project_id,))

            # 3. 删除任务记录
            cursor.execute("DELETE FROM tasks WHERE project_id = %s", (project_id,))

            # 4. 删除项目记录（sample、experiment_reports 有 CASCADE，会自动删除）
            cursor.execute("DELETE FROM projects WHERE id = %s", (project_id,))

            conn.commit()
        except Exception:
            conn.rollback()
            raise

        conn.close()

        return {
            "success": True,
            "message": "项目删除成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除项目错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/projects/search/{keyword}")
async def search_projects(keyword: str):
    """搜索项目"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        search_pattern = f"%{keyword}%"
        query = """
        SELECT p.*, e.unit_name as entrust_unit_name 
        FROM projects p 
        LEFT JOIN entrust_units e ON p.entrust_unit_id = e.id 
        WHERE p.project_name LIKE %s OR p.project_code LIKE %s 
           OR e.unit_name LIKE %s OR p.test_type LIKE %s
        ORDER BY p.created_at DESC
        """
        cursor.execute(query, (search_pattern, search_pattern, search_pattern, search_pattern))
        projects = cursor.fetchall()

        conn.close()

        return {
            "success": True,
            "message": f"找到 {len(projects)} 个匹配的项目",
            "data": projects,
            "total": len(projects)
        }

    except Exception as e:
        print(f"搜索项目错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
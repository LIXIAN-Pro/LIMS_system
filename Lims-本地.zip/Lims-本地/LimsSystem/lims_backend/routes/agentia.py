from fastapi import APIRouter, HTTPException
import database
from models import AgentiaCreate, AgentiaUpdate, AgentiaQuantityUpdate

router = APIRouter()

@router.get("/api/agentia")
async def get_agentia(status: str = None):
    """获取所有试剂（可筛选状态）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 如果有状态参数，进行筛选
        if status:
            if status not in ["available", "low_stock", "out_of_stock"]:
                raise HTTPException(status_code=400, detail="状态值必须是 'available'、'low_stock' 或 'out_of_stock'")
            query = "SELECT * FROM agentia WHERE status = %s ORDER BY created_at DESC"
            cursor.execute(query, (status,))
        else:
            query = "SELECT * FROM agentia ORDER BY created_at DESC"
            cursor.execute(query)
            
        agentia = cursor.fetchall()

        conn.close()

        return {"success": True, "data": agentia}

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取试剂列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/agentia/{agentia_id}")
async def get_agentia_by_id(agentia_id: int):
    """获取单个试剂"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM agentia WHERE id = %s"
        cursor.execute(query, (agentia_id,))
        agentia = cursor.fetchone()

        conn.close()

        if agentia:
            return {"success": True, "data": agentia}
        else:
            raise HTTPException(status_code=404, detail="试剂不存在")

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取试剂错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/agentia/available")
async def get_available_agentia():
    """获取可用的试剂（库存大于0）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT * FROM agentia 
        WHERE quantity > 0 AND status != 'out_of_stock'
        ORDER BY name
        """
        cursor.execute(query)
        agentia = cursor.fetchall()

        conn.close()

        return {"success": True, "data": agentia}

    except Exception as e:
        print(f"获取可用试剂列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/agentia")
async def create_agentia(agentia: AgentiaCreate):
    """创建试剂"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查试剂编号是否已存在
        check_query = "SELECT id FROM agentia WHERE agentia_code = %s"
        cursor.execute(check_query, (agentia.agentia_code,))
        existing = cursor.fetchone()

        if existing:
            conn.close()
            raise HTTPException(status_code=400, detail="试剂编号已存在")

        # 验证状态值
        if agentia.status not in ["available", "low_stock", "out_of_stock"]:
            conn.close()
            raise HTTPException(status_code=400, detail="状态值必须是 'available'、'low_stock' 或 'out_of_stock'")

        # 根据库存数量自动更新状态
        status = agentia.status
        if agentia.quantity == 0:
            status = "out_of_stock"
        elif agentia.quantity <= 5:
            status = "low_stock"
        else:
            status = "available"

        # 插入新记录
        insert_query = """
        INSERT INTO agentia
        (name, agentia_code, capacity, quantity, status)
        VALUES (%s, %s, %s, %s, %s)
        """

        cursor.execute(insert_query, (
            agentia.name,
            agentia.agentia_code,
            agentia.capacity,
            agentia.quantity,
            status
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = "SELECT * FROM agentia WHERE id = LAST_INSERT_ID()"
        cursor.execute(get_query)
        new_agentia = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "试剂创建成功",
            "data": new_agentia
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"创建试剂错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/agentia/{agentia_id}")
async def update_agentia(agentia_id: int, agentia: AgentiaUpdate):
    """更新试剂"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM agentia WHERE id = %s"
        cursor.execute(check_query, (agentia_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="试剂不存在")

        # 检查试剂编号是否与其他记录冲突
        check_agentia_code = """
        SELECT id FROM agentia WHERE agentia_code = %s AND id != %s
        """
        cursor.execute(check_agentia_code, (agentia.agentia_code, agentia_id))
        conflict = cursor.fetchone()

        if conflict:
            conn.close()
            raise HTTPException(status_code=400, detail="试剂编号已被其他试剂使用")

        # 验证状态值
        if agentia.status not in ["available", "low_stock", "out_of_stock"]:
            conn.close()
            raise HTTPException(status_code=400, detail="状态值必须是 'available'、'low_stock' 或 'out_of_stock'")

        # 根据库存数量自动更新状态
        status = agentia.status
        if agentia.quantity == 0:
            status = "out_of_stock"
        elif agentia.quantity <= 5:
            status = "low_stock"
        else:
            status = "available"

        # 更新记录
        update_query = """
        UPDATE agentia
        SET name = %s, agentia_code = %s, capacity = %s,
            quantity = %s, status = %s, updated_at = NOW()
        WHERE id = %s
        """

        cursor.execute(update_query, (
            agentia.name,
            agentia.agentia_code,
            agentia.capacity,
            agentia.quantity,
            status,
            agentia_id
        ))

        conn.commit()

        # 获取更新后的记录
        get_query = "SELECT * FROM agentia WHERE id = %s"
        cursor.execute(get_query, (agentia_id,))
        updated_agentia = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "试剂更新成功",
            "data": updated_agentia
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新试剂错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/agentia/{agentia_id}/quantity")
async def update_agentia_quantity(agentia_id: int, update_data: AgentiaQuantityUpdate):
    """更新试剂库存数量"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id, capacity FROM agentia WHERE id = %s"
        cursor.execute(check_query, (agentia_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="试剂不存在")

        # 根据库存数量自动更新状态
        if update_data.quantity == 0:
            status = "out_of_stock"
        elif update_data.quantity <= 5:
            status = "low_stock"
        else:
            status = "available"

        # 更新记录
        update_query = """
        UPDATE agentia
        SET quantity = %s, status = %s, updated_at = NOW()
        WHERE id = %s
        """

        cursor.execute(update_query, (
            update_data.quantity,
            status,
            agentia_id
        ))

        conn.commit()

        # 获取更新后的记录
        get_query = "SELECT * FROM agentia WHERE id = %s"
        cursor.execute(get_query, (agentia_id,))
        updated_agentia = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "试剂库存更新成功",
            "data": updated_agentia
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新试剂库存错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/agentia/{agentia_id}")
async def delete_agentia(agentia_id: int):
    """删除试剂 - 允许删除有历史任务关联的试剂"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id, name FROM agentia WHERE id = %s"
        cursor.execute(check_query, (agentia_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="试剂不存在")

        agentia_name = existing['name']

        # 检查是否有关联任务（进行中或待开始）
        cursor.execute(
            "SELECT COUNT(*) as cnt FROM tasks WHERE agentia_id = %s AND status IN ('pending', 'in_progress')",
            (agentia_id,)
        )
        active_count = cursor.fetchone()['cnt']
        if active_count > 0:
            conn.close()
            raise HTTPException(
                status_code=400,
                detail=f"该试剂有 {active_count} 个进行中/待开始的任务正在使用，无法删除。请先取消相关任务。"
            )

        # 开启事务
        cursor.execute("START TRANSACTION")

        try:
            # 获取历史任务数量
            cursor.execute(
                "SELECT COUNT(*) as cnt FROM tasks WHERE agentia_id = %s",
                (agentia_id,)
            )
            history_count = cursor.fetchone()['cnt']

            # 解除所有任务关联（包括历史任务）
            cursor.execute(
                "UPDATE tasks SET agentia_id = NULL WHERE agentia_id = %s",
                (agentia_id,)
            )

            # 删除试剂记录
            cursor.execute("DELETE FROM agentia WHERE id = %s", (agentia_id,))

            conn.commit()

            resource_info = f"，已解除 {history_count} 条历史任务关联" if history_count > 0 else ""

            conn.close()

            return {
                "success": True,
                "message": f"试剂「{agentia_name}」删除成功{resource_info}"
            }

        except Exception as tx_error:
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"删除试剂事务失败: {str(tx_error)}")

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除试剂错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/agentia/search/{keyword}")
async def search_agentia(keyword: str, status: str = None):
    """搜索试剂"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        search_pattern = f"%{keyword}%"
        
        if status:
            if status not in ["available", "low_stock", "out_of_stock"]:
                raise HTTPException(status_code=400, detail="状态值必须是 'available'、'low_stock' 或 'out_of_stock'")
            query = """
            SELECT * FROM agentia
            WHERE (name LIKE %s OR agentia_code LIKE %s)
            AND status = %s
            ORDER BY created_at DESC
            """
            cursor.execute(query, (search_pattern, search_pattern, status))
        else:
            query = """
            SELECT * FROM agentia
            WHERE name LIKE %s OR agentia_code LIKE %s
            ORDER BY created_at DESC
            """
            cursor.execute(query, (search_pattern, search_pattern))
            
        agentia = cursor.fetchall()

        conn.close()

        return {
            "success": True,
            "message": f"找到 {len(agentia)} 个匹配的试剂",
            "data": agentia,
            "total": len(agentia)
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"搜索试剂错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
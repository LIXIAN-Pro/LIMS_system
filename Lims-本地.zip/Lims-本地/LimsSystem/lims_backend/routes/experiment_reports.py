# routes/experiment_reports.py
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
import database
import os
from datetime import datetime
from typing import Optional
import uuid
import urllib.parse
import mimetypes

router = APIRouter()

# 上传目录
UPLOAD_DIR = "uploads/experiment_reports"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.get("/api/experiment-reports")
async def get_experiment_reports():
    """获取所有实验报告列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT er.*, p.project_code, p.project_name, lp.name as personnel_name
        FROM experiment_reports er
        LEFT JOIN projects p ON er.project_id = p.id
        LEFT JOIN lab_personnel lp ON er.personnel_id = lp.id
        ORDER BY er.upload_time DESC
        """
        cursor.execute(query)
        reports = cursor.fetchall()

        # 为每个报告获取采集人员信息
        for report in reports:
            # 通过项目ID找到对应的已完成任务，然后获取采集人员
            cursor.execute("""
            SELECT c.name
            FROM tasks t
            JOIN task_collectors tc ON t.id = tc.task_id
            JOIN collectors c ON tc.collector_id = c.id
            WHERE t.project_id = %s AND t.status = 'completed'
            ORDER BY c.name
            """, (report['project_id'],))
            collectors = cursor.fetchall()
            report['collectors'] = collectors

        conn.close()

        return {"success": True, "data": reports}

    except Exception as e:
        print(f"获取实验报告列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/experiment-reports/uploaded-projects")
async def get_uploaded_projects():
    """获取已上传实验报告的项目ID列表，用于前端灰色显示"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT DISTINCT project_id FROM experiment_reports"
        cursor.execute(query)
        result = cursor.fetchall()

        conn.close()

        project_ids = [row['project_id'] for row in result]
        return {"success": True, "data": project_ids}

    except Exception as e:
        print(f"获取已上传项目列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/experiment-reports/upload")
async def upload_experiment_report(
    project_id: int = Form(...),
    personnel_id: int = Form(...),
    file: UploadFile = File(...)
):
    """上传实验报告"""
    try:
        # 验证文件类型
        allowed_extensions = {'.doc', '.docx', '.pdf', '.xlsx', '.xls'}
        file_extension = os.path.splitext(file.filename)[1].lower()

        if file_extension not in allowed_extensions:
            raise HTTPException(status_code=400, detail="只允许上传Word、PDF、Excel格式的文件")

        # 验证文件大小（限制为50MB）
        max_size = 50 * 1024 * 1024  # 50MB
        if file.size and file.size > max_size:
            raise HTTPException(status_code=400, detail="文件大小不能超过50MB")

        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 验证项目是否存在
        project_query = "SELECT id, project_code, project_name FROM projects WHERE id = %s"
        cursor.execute(project_query, (project_id,))
        project = cursor.fetchone()

        if not project:
            conn.close()
            raise HTTPException(status_code=404, detail="项目不存在")

        # 验证实验人员是否存在
        personnel_query = "SELECT id, name FROM lab_personnel WHERE id = %s"
        cursor.execute(personnel_query, (personnel_id,))
        personnel = cursor.fetchone()

        if not personnel:
            conn.close()
            raise HTTPException(status_code=404, detail="实验人员不存在")

        # 检查是否已为该项目上传过实验报告
        check_query = "SELECT id FROM experiment_reports WHERE project_id = %s"
        cursor.execute(check_query, (project_id,))
        existing_report = cursor.fetchone()

        if existing_report:
            conn.close()
            raise HTTPException(status_code=400, detail="该项目已上传实验报告")

        # 生成唯一文件名
        unique_filename = f"{uuid.uuid4().hex}_{file.filename}"
        file_path = os.path.join(UPLOAD_DIR, unique_filename)

        # 保存文件
        try:
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
        except Exception as e:
            print(f"文件保存失败: {e}")
            raise HTTPException(status_code=500, detail="文件保存失败")

        # 插入数据库记录
        insert_query = """
        INSERT INTO experiment_reports
        (project_id, project_code, project_name, personnel_id, personnel_name,
         report_filename, original_filename, file_path, file_size, upload_time, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), 'uploaded')
        """

        cursor.execute(insert_query, (
            project_id,
            project['project_code'],
            project['project_name'],
            personnel_id,
            personnel['name'],
            unique_filename,
            file.filename,
            file_path,
            file.size or len(content),
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = """
        SELECT er.*, p.project_code, p.project_name, lp.name as personnel_name
        FROM experiment_reports er
        LEFT JOIN projects p ON er.project_id = p.id
        LEFT JOIN lab_personnel lp ON er.personnel_id = lp.id
        WHERE er.id = LAST_INSERT_ID()
        """
        cursor.execute(get_query)
        new_report = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "实验报告上传成功",
            "data": new_report
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"上传实验报告错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/experiment-reports/{report_id}/download")
async def download_experiment_report(report_id: int):
    """下载实验报告"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM experiment_reports WHERE id = %s"
        cursor.execute(query, (report_id,))
        report = cursor.fetchone()

        conn.close()

        if not report:
            raise HTTPException(status_code=404, detail="实验报告不存在")

        if not os.path.exists(report['file_path']):
            raise HTTPException(status_code=404, detail="文件不存在")

        from fastapi.responses import FileResponse
        import urllib.parse
        import mimetypes

        # 根据文件扩展名确定正确的MIME类型
        mime_type, _ = mimetypes.guess_type(report['original_filename'])
        if mime_type is None:
            mime_type = 'application/octet-stream'

        # 设置正确的Content-Disposition头，确保文件名正确编码
        encoded_filename = urllib.parse.quote(report['original_filename'])
        headers = {
            'Content-Disposition': f'attachment; filename*=UTF-8\'\'{encoded_filename}'
        }

        return FileResponse(
            path=report['file_path'],
            filename=report['original_filename'],
            media_type=mime_type,
            headers=headers
        )

    except HTTPException:
        raise
    except Exception as e:
        print(f"下载实验报告错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/experiment-reports/{report_id}")
async def delete_experiment_report(report_id: int):
    """删除实验报告"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 获取报告信息
        query = "SELECT * FROM experiment_reports WHERE id = %s"
        cursor.execute(query, (report_id,))
        report = cursor.fetchone()

        if not report:
            conn.close()
            raise HTTPException(status_code=404, detail="实验报告不存在")

        # 删除文件
        if os.path.exists(report['file_path']):
            try:
                os.remove(report['file_path'])
            except Exception as e:
                print(f"删除文件失败: {e}")

        # 删除数据库记录
        delete_query = "DELETE FROM experiment_reports WHERE id = %s"
        cursor.execute(delete_query, (report_id,))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "实验报告删除成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除实验报告错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

# 审核相关API
@router.get("/api/experiment-edit-reports/secondary-audit")
async def get_secondary_audit_reports():
    """获取待二级审核的编制报告列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT eer.*, er.project_code, er.project_name, er.personnel_name
        FROM experiment_edit_reports eer
        LEFT JOIN experiment_reports er ON eer.experiment_report_id = er.id
        WHERE eer.review_level = 1 AND eer.review_status = 'pending'
        ORDER BY eer.upload_time DESC
        """
        cursor.execute(query)
        reports = cursor.fetchall()

        conn.close()

        return {"success": True, "data": reports}

    except Exception as e:
        print(f"获取二级审核列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/experiment-edit-reports/tertiary-audit")
async def get_tertiary_audit_reports():
    """获取待三级审核的编制报告列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT eer.*, er.project_code, er.project_name, er.personnel_name, er.project_id
        FROM experiment_edit_reports eer
        LEFT JOIN experiment_reports er ON eer.experiment_report_id = er.id
        WHERE eer.review_level = 2 AND eer.review_status = 'approved'
        ORDER BY eer.reviewed_at DESC
        """
        cursor.execute(query)
        reports = cursor.fetchall()

        conn.close()

        return {"success": True, "data": reports}

    except Exception as e:
        print(f"获取三级审核列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/experiment-edit-reports/{report_id}/secondary-approve")
async def secondary_approve_report(report_id: int, request: dict):
    """二级审核通过"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查报告是否存在且状态正确
        check_query = "SELECT * FROM experiment_edit_reports WHERE id = %s AND review_level = 1 AND review_status = 'pending'"
        cursor.execute(check_query, (report_id,))
        report = cursor.fetchone()

        if not report:
            conn.close()
            raise HTTPException(status_code=404, detail="报告不存在或状态不正确")

        # 更新审核状态
        update_query = """
        UPDATE experiment_edit_reports
        SET review_level = 2, review_status = 'approved', reviewed_by = %s, reviewed_at = NOW()
        WHERE id = %s
        """
        cursor.execute(update_query, (request.get('reviewed_by', ''), report_id))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "二级审核通过，该报告进入三级审核"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"二级审核通过错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/experiment-edit-reports/{report_id}/secondary-reject")
async def secondary_reject_report(report_id: int, request: dict):
    """二级审核不通过"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查报告是否存在且状态正确
        check_query = "SELECT * FROM experiment_edit_reports WHERE id = %s AND review_level = 1 AND review_status = 'pending'"
        cursor.execute(check_query, (report_id,))
        report = cursor.fetchone()

        if not report:
            conn.close()
            raise HTTPException(status_code=404, detail="报告不存在或状态不正确")

        # 更新审核状态
        update_query = """
        UPDATE experiment_edit_reports
        SET review_level = 1, review_status = 'rejected', review_notes = %s, reviewed_by = %s, reviewed_at = NOW()
        WHERE id = %s
        """
        cursor.execute(update_query, (
            request.get('review_notes', ''),
            request.get('reviewed_by', ''),
            report_id
        ))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "二级审核不通过，该报告已回退到编制页面"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"二级审核不通过错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/experiment-edit-reports/{report_id}/tertiary-approve")
async def tertiary_approve_report(report_id: int, request: dict):
    """三级审核通过"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查报告是否存在且状态正确
        check_query = "SELECT * FROM experiment_edit_reports WHERE id = %s AND review_level = 2 AND review_status = 'approved'"
        cursor.execute(check_query, (report_id,))
        report = cursor.fetchone()

        if not report:
            conn.close()
            raise HTTPException(status_code=404, detail="报告不存在或状态不正确")

        # 更新审核状态
        update_query = """
        UPDATE experiment_edit_reports
        SET review_level = 3, reviewed_by = %s, reviewed_at = NOW()
        WHERE id = %s
        """
        cursor.execute(update_query, (request.get('reviewed_by', ''), report_id))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "三级审核通过，报告审核流程完成"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"三级审核通过错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/experiment-edit-reports/{report_id}/tertiary-reject")
async def tertiary_reject_report(report_id: int, request: dict):
    """三级审核不通过"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查报告是否存在且状态正确
        check_query = "SELECT * FROM experiment_edit_reports WHERE id = %s AND review_level = 2 AND review_status = 'approved'"
        cursor.execute(check_query, (report_id,))
        report = cursor.fetchone()

        if not report:
            conn.close()
            raise HTTPException(status_code=404, detail="报告不存在或状态不正确")

        # 更新审核状态
        update_query = """
        UPDATE experiment_edit_reports
        SET review_level = 1, review_status = 'rejected', review_notes = %s, reviewed_by = %s, reviewed_at = NOW()
        WHERE id = %s
        """
        cursor.execute(update_query, (
            request.get('review_notes', ''),
            request.get('reviewed_by', ''),
            report_id
        ))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "三级审核不通过，该报告已回退到编制页面"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"三级审核不通过错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
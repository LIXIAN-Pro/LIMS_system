from fastapi import APIRouter, HTTPException
import database
from models import EquipmentCreate, EquipmentUpdate

router = APIRouter()

@router.get("/api/equipment")
async def get_equipment(status: str = None):
    """获取所有设备（可筛选状态）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 如果有状态参数，进行筛选
        if status:
            if status not in ["idle", "in_use", "maintenance"]:
                raise HTTPException(status_code=400, detail="状态值必须是 'idle'、'in_use' 或 'maintenance'")
            query = "SELECT * FROM equipment WHERE status = %s ORDER BY created_at DESC"
            cursor.execute(query, (status,))
        else:
            query = "SELECT * FROM equipment ORDER BY created_at DESC"
            cursor.execute(query)
            
        equipment = cursor.fetchall()

        conn.close()

        return {"success": True, "data": equipment}

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取设备列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/equipment/{equipment_id}")
async def get_equipment_by_id(equipment_id: int):
    """获取单个设备"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM equipment WHERE id = %s"
        cursor.execute(query, (equipment_id,))
        equipment = cursor.fetchone()

        conn.close()

        if equipment:
            return {"success": True, "data": equipment}
        else:
            raise HTTPException(status_code=404, detail="设备不存在")

    except HTTPException:
        raise
    except Exception as e:
        print(f"获取设备错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/equipment/available")
async def get_available_equipment():
    """获取可用的设备（状态为空闲）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = "SELECT * FROM equipment WHERE status = 'idle' ORDER BY name"
        cursor.execute(query)
        equipment = cursor.fetchall()

        conn.close()

        return {"success": True, "data": equipment}

    except Exception as e:
        print(f"获取可用设备列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.post("/api/equipment")
async def create_equipment(equipment: EquipmentCreate):
    """创建设备"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查设备编号是否已存在
        check_query = "SELECT id FROM equipment WHERE equipment_code = %s"
        cursor.execute(check_query, (equipment.equipment_code,))
        existing = cursor.fetchone()

        if existing:
            conn.close()
            raise HTTPException(status_code=400, detail="设备编号已存在")

        # 验证采集类型
        if equipment.collection_type not in ["wastewater", "wastegas", "particle"]:
            conn.close()
            raise HTTPException(status_code=400, detail="采集类型必须是 'wastewater'、'wastegas' 或 'particle'")

        # 验证状态值
        if equipment.status not in ["idle", "in_use", "maintenance"]:
            conn.close()
            raise HTTPException(status_code=400, detail="状态值必须是 'idle'、'in_use' 或 'maintenance'")

        # 插入新记录
        insert_query = """
        INSERT INTO equipment
        (name, equipment_code, collection_type, location, status)
        VALUES (%s, %s, %s, %s, %s)
        """

        cursor.execute(insert_query, (
            equipment.name,
            equipment.equipment_code,
            equipment.collection_type,
            equipment.location,
            equipment.status
        ))

        conn.commit()

        # 获取刚插入的记录
        get_query = "SELECT * FROM equipment WHERE id = LAST_INSERT_ID()"
        cursor.execute(get_query)
        new_equipment = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "设备创建成功",
            "data": new_equipment
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"创建设备错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/equipment/{equipment_id}")
async def update_equipment(equipment_id: int, equipment: EquipmentUpdate):
    """更新设备"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM equipment WHERE id = %s"
        cursor.execute(check_query, (equipment_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="设备不存在")

        # 检查设备编号是否与其他记录冲突
        check_equipment_code = """
        SELECT id FROM equipment WHERE equipment_code = %s AND id != %s
        """
        cursor.execute(check_equipment_code, (equipment.equipment_code, equipment_id))
        conflict = cursor.fetchone()

        if conflict:
            conn.close()
            raise HTTPException(status_code=400, detail="设备编号已被其他设备使用")

        # 验证采集类型
        if equipment.collection_type not in ["wastewater", "wastegas", "particle"]:
            conn.close()
            raise HTTPException(status_code=400, detail="采集类型必须是 'wastewater'、'wastegas' 或 'particle'")

        # 验证状态值
        if equipment.status not in ["idle", "in_use", "maintenance"]:
            conn.close()
            raise HTTPException(status_code=400, detail="状态值必须是 'idle'、'in_use' 或 'maintenance'")

        # 更新记录
        update_query = """
        UPDATE equipment
        SET name = %s, equipment_code = %s, collection_type = %s,
            location = %s, status = %s, updated_at = NOW()
        WHERE id = %s
        """

        cursor.execute(update_query, (
            equipment.name,
            equipment.equipment_code,
            equipment.collection_type,
            equipment.location,
            equipment.status,
            equipment_id
        ))

        conn.commit()

        # 获取更新后的记录
        get_query = "SELECT * FROM equipment WHERE id = %s"
        cursor.execute(get_query, (equipment_id,))
        updated_equipment = cursor.fetchone()

        conn.close()

        return {
            "success": True,
            "message": "设备更新成功",
            "data": updated_equipment
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"更新设备错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/equipment/{equipment_id}")
async def delete_equipment(equipment_id: int):
    """删除设备"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查记录是否存在
        check_query = "SELECT id FROM equipment WHERE id = %s"
        cursor.execute(check_query, (equipment_id,))
        existing = cursor.fetchone()

        if not existing:
            conn.close()
            raise HTTPException(status_code=404, detail="设备不存在")

        # 检查是否有进行中/待开始的任务使用该设备
        cursor.execute(
            "SELECT COUNT(*) as cnt FROM tasks WHERE equipment_id = %s AND status IN ('pending', 'in_progress')",
            (equipment_id,)
        )
        active_count = cursor.fetchone()['cnt']
        if active_count > 0:
            conn.close()
            raise HTTPException(
                status_code=400,
                detail=f"该设备有 {active_count} 个进行中/待开始的任务，无法删除。请先完成或取消关联任务。"
            )

        # 先解除所有任务对该设备的引用（包括已完成/已取消的任务）
        # 这样可以避免外键约束冲突
        cursor.execute(
            "UPDATE tasks SET equipment_id = NULL WHERE equipment_id = %s",
            (equipment_id,)
        )

        # 删除记录
        delete_query = "DELETE FROM equipment WHERE id = %s"
        cursor.execute(delete_query, (equipment_id,))

        conn.commit()

        conn.close()

        return {
            "success": True,
            "message": "设备删除成功"
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除设备错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/equipment/search/{keyword}")
async def search_equipment(keyword: str, status: str = None):
    """搜索设备（按设备名称或设备编号）"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        search_pattern = f"%{keyword}%"
        
        if status:
            if status not in ["idle", "in_use", "maintenance"]:
                raise HTTPException(status_code=400, detail="状态值必须是 'idle'、'in_use' 或 'maintenance'")
            query = """
            SELECT * FROM equipment
            WHERE (name LIKE %s OR equipment_code LIKE %s)
            AND status = %s
            ORDER BY created_at DESC
            """
            cursor.execute(query, (search_pattern, search_pattern, status))
        else:
            query = """
            SELECT * FROM equipment
            WHERE name LIKE %s OR equipment_code LIKE %s
            ORDER BY created_at DESC
            """
            cursor.execute(query, (search_pattern, search_pattern))
            
        equipment = cursor.fetchall()

        conn.close()

        return {
            "success": True,
            "message": f"找到 {len(equipment)} 个匹配的设备",
            "data": equipment,
            "total": len(equipment)
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"搜索设备错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
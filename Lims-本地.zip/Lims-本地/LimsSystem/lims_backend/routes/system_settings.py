from fastapi import APIRouter, HTTPException
import database
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from email.utils import formataddr
import ssl

from models import SmtpSettings, TestEmailSendRequest

router = APIRouter()

# SMTP设置相关的键名常量
SMTP_SETTINGS_KEYS = {
    'server': 'smtp_server',
    'port': 'smtp_port',
    'sender_email': 'smtp_sender_email',
    'sender_password': 'smtp_sender_password',
    'sender_name': 'smtp_sender_name',
    'use_ssl': 'smtp_use_ssl'
}

@router.get("/api/system/smtp-settings")
async def get_smtp_settings():
    """获取SMTP邮箱设置"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        settings = {}
        for key, setting_key in SMTP_SETTINGS_KEYS.items():
            query = """
                SELECT setting_value FROM system_settings
                WHERE setting_key = %s AND setting_group = 'smtp'
            """
            cursor.execute(query, (setting_key,))
            result = cursor.fetchone()

            if result and result['setting_value']:
                if key == 'port':
                    settings[key] = int(result['setting_value'])
                elif key == 'use_ssl':
                    settings[key] = result['setting_value'].lower() == 'true'
                else:
                    settings[key] = result['setting_value']

        # 如果没有设置，返回默认值
        if not settings:
            settings = {
                'server': '',
                'port': 587,
                'sender_email': '',
                'sender_password': '',
                'sender_name': '',
                'use_ssl': True
            }

        conn.close()
        return {
            "success": True,
            "message": "获取SMTP设置成功",
            "data": settings
        }
    except Exception as e:
        if 'conn' in locals():
            conn.close()
        raise HTTPException(status_code=500, detail=f"获取SMTP设置失败: {str(e)}")

@router.get("/api/system/collector-email/{collector_name}")
async def get_collector_email(collector_name: str):
    """根据采集人员姓名获取对应的用户邮箱"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 根据采集人员姓名查找对应的用户邮箱
        query = """
            SELECT email FROM lab_staff
            WHERE name = %s AND email IS NOT NULL AND email != ''
            LIMIT 1
        """
        cursor.execute(query, (collector_name,))
        result = cursor.fetchone()

        conn.close()

        if result and result['email']:
            return {
                "success": True,
                "message": f"找到采集人员 {collector_name} 对应的邮箱",
                "data": {
                    "collector_name": collector_name,
                    "email": result['email']
                }
            }
        else:
            return {
                "success": False,
                "message": f"未找到采集人员 {collector_name} 对应的用户邮箱",
                "data": None
            }
    except Exception as e:
        if 'conn' in locals():
            conn.close()
        raise HTTPException(status_code=500, detail=f"查找用户邮箱失败: {str(e)}")

@router.post("/api/system/smtp-settings")
async def save_smtp_settings(settings: SmtpSettings):
    """保存SMTP邮箱设置"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 验证设置
        if not settings.server or not settings.sender_email or not settings.sender_password:
            conn.close()
            raise HTTPException(status_code=400, detail="SMTP服务器、发件人邮箱和密码不能为空")

        if settings.port <= 0 or settings.port > 65535:
            conn.close()
            raise HTTPException(status_code=400, detail="端口号必须在1-65535之间")

        # 保存或更新设置
        for key, setting_key in SMTP_SETTINGS_KEYS.items():
            value = getattr(settings, key)

            # 布尔值转换为字符串
            if isinstance(value, bool):
                value = 'true' if value else 'false'

            # 检查是否存在
            check_query = """
                SELECT id FROM system_settings
                WHERE setting_key = %s AND setting_group = 'smtp'
            """
            cursor.execute(check_query, (setting_key,))
            existing = cursor.fetchone()

            if existing:
                # 更新
                update_query = """
                    UPDATE system_settings
                    SET setting_value = %s, is_encrypted = %s, updated_at = NOW()
                    WHERE setting_key = %s AND setting_group = 'smtp'
                """
                cursor.execute(update_query, (value, key == 'sender_password', setting_key))
            else:
                # 插入
                insert_query = """
                    INSERT INTO system_settings (setting_key, setting_value, setting_group, description, is_encrypted, created_at, updated_at)
                    VALUES (%s, %s, 'smtp', %s, %s, NOW(), NOW())
                """
                cursor.execute(insert_query, (setting_key, value, get_setting_description(key), key == 'sender_password'))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "SMTP设置保存成功"
        }
    except HTTPException:
        raise
    except Exception as e:
        if 'conn' in locals():
            conn.rollback()
            conn.close()
        raise HTTPException(status_code=500, detail=f"保存SMTP设置失败: {str(e)}")

@router.post("/api/system/test-email-send")
async def test_email_send(request: TestEmailSendRequest):
    """测试邮件发送"""
    try:
        # 获取SMTP设置
        settings_response = await get_smtp_settings()
        if not settings_response["success"]:
            raise HTTPException(status_code=400, detail="SMTP设置未配置或配置不完整")

        settings = settings_response["data"]

        # 验证配置
        if not settings.get('server') or not settings.get('sender_email') or not settings.get('sender_password'):
            raise HTTPException(status_code=400, detail="SMTP配置不完整，请先保存完整的SMTP设置")

        # 发送测试邮件
        success = await send_test_email(settings, request.recipient, request.subject, request.content)

        if success:
            return {
                "success": True,
                "message": f"测试邮件已成功发送至 {request.recipient}"
            }
        else:
            raise HTTPException(status_code=500, detail="邮件发送失败，请检查SMTP配置")

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"测试邮件发送失败: {str(e)}")

async def send_test_email(smtp_config: dict, recipient: str, subject: str = None, content: str = None) -> bool:
    """发送测试邮件"""
    server = None
    try:
        # 默认邮件内容
        if not subject:
            subject = "LIMS系统邮件测试"
        if not content:
            content = "这是一封测试邮件，用于验证SMTP配置是否正确。"

        # 创建邮件
        msg = MIMEMultipart()

        # 设置From头 - 使用最简单的格式
        sender_email = smtp_config['sender_email']
        msg['From'] = sender_email
        msg['To'] = recipient
        msg['Subject'] = subject

        # 添加邮件正文
        msg.attach(MIMEText(content, 'plain', 'utf-8'))

        # SMTP服务器配置
        server = smtplib.SMTP(smtp_config['server'], smtp_config['port'])
        server.set_debuglevel(0)  # 关闭调试信息

        # 启用SSL/TLS
        if smtp_config.get('use_ssl', True):
            # 创建SSL上下文
            context = ssl._create_unverified_context()
            server.starttls(context=context)

        # 登录
        server.login(smtp_config['sender_email'], smtp_config['sender_password'])

        # 发送邮件
        server.sendmail(smtp_config['sender_email'], recipient, msg.as_string())

        return True

    except smtplib.SMTPAuthenticationError as e:
        raise HTTPException(status_code=400, detail=f"SMTP认证失败，请检查邮箱地址和密码/授权码: {str(e)}")
    except smtplib.SMTPConnectError as e:
        raise HTTPException(status_code=400, detail=f"无法连接到SMTP服务器，请检查服务器地址和端口: {str(e)}")
    except smtplib.SMTPException as e:
        raise HTTPException(status_code=400, detail=f"SMTP错误: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"邮件发送失败: {str(e)}")
    finally:
        if server:
            try:
                server.quit()
            except:
                pass

def get_setting_description(key: str) -> str:
    """获取设置项的描述"""
    descriptions = {
        'server': 'SMTP服务器地址',
        'port': 'SMTP服务器端口',
        'sender_email': '发件人邮箱地址',
        'sender_password': '发件人邮箱密码或授权码',
        'sender_name': '发件人显示名称',
        'use_ssl': '是否使用SSL加密连接'
    }
    return descriptions.get(key, '')
# routes/task_submissions.py
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
import os
import shutil
from datetime import datetime
from typing import Optional
import database

router = APIRouter()

UPLOAD_DIR = "uploads/task_submissions"

# 确保上传目录存在
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/api/tasks/{task_id}/upload")
async def upload_task_file(
    task_id: int,
    file: UploadFile = File(...),
    submitter_id: Optional[int] = Form(None)
):
    """上传任务文件"""
    try:
        # 验证任务是否存在且状态允许上传
        conn = database.get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT status, project_code FROM tasks WHERE id = %s", (task_id,))
        task = cursor.fetchone()

        if not task:
            conn.close()
            raise HTTPException(status_code=404, detail="任务不存在")

        if task['status'] not in ['in_progress', 'pending']:
            conn.close()
            raise HTTPException(status_code=400, detail="任务状态不允许上传文件")

        project_code = task['project_code']

        # 创建任务专用目录
        task_dir = os.path.join(UPLOAD_DIR, str(task_id))
        os.makedirs(task_dir, exist_ok=True)

        # 生成文件名（添加时间戳避免重复）
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        original_name = file.filename
        name_parts = os.path.splitext(original_name)
        new_filename = f"{name_parts[0]}_{timestamp}{name_parts[1]}"
        file_path = os.path.join(task_dir, new_filename)

        # 保存文件
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # 获取文件大小
        file_size = os.path.getsize(file_path)

        # 插入数据库记录
        insert_query = """
        INSERT INTO submit
        (task_id, project_code, file_name, file_path, file_size, submitter_id)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (
            task_id,
            project_code,   # 项目编号
            original_name,  # 存储原始文件名
            file_path,      # 存储实际存储路径
            file_size,
            submitter_id
        ))

        conn.commit()
        conn.close()

        return {
            "success": True,
            "message": "文件上传成功",
            "data": {
                "file_name": original_name,
                "file_path": file_path,
                "file_size": file_size,
                "upload_time": datetime.now().isoformat()
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"上传文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.put("/api/tasks/{task_id}/submit")
async def submit_task(task_id: int):
    """提交任务"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 检查任务是否存在且有上传的文件
        cursor.execute("SELECT status, project_code FROM tasks WHERE id = %s", (task_id,))
        task = cursor.fetchone()

        if not task:
            conn.close()
            raise HTTPException(status_code=404, detail="任务不存在")

        if task['status'] != 'in_progress':
            conn.close()
            raise HTTPException(status_code=400, detail="只有进行中的任务才能提交")

        # 检查是否有上传的文件
        cursor.execute("SELECT COUNT(*) as file_count FROM submit WHERE task_id = %s", (task_id,))
        file_check = cursor.fetchone()

        if file_check['file_count'] == 0:
            conn.close()
            raise HTTPException(status_code=400, detail="请先上传文件后再提交任务")

        try:
            # 更新任务状态为已提交（或完成，根据业务逻辑）
            cursor.execute("""
            UPDATE tasks
            SET status = 'completed', updated_at = NOW()
            WHERE id = %s
            """, (task_id,))

            # 只释放当前任务自己绑定的设备
            cursor.execute("SELECT equipment_id FROM tasks WHERE id = %s", (task_id,))
            task_equip = cursor.fetchone()
            if task_equip and task_equip['equipment_id']:
                cursor.execute(
                    "UPDATE equipment SET status = 'idle' WHERE id = %s",
                    (task_equip['equipment_id'],)
                )

            conn.commit()
        except Exception:
            conn.rollback()
            raise
        conn.close()

        return {"success": True, "message": "任务提交成功"}

    except HTTPException:
        raise
    except Exception as e:
        print(f"提交任务错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/tasks/{task_id}/files")
async def get_task_files(task_id: int):
    """获取任务的文件列表"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        query = """
        SELECT id, task_id, project_code, file_name, file_path, file_size, upload_time
        FROM submit
        WHERE task_id = %s
        ORDER BY upload_time DESC
        """
        cursor.execute(query, (task_id,))
        files = cursor.fetchall()

        conn.close()

        return {"success": True, "data": files}

    except Exception as e:
        print(f"获取任务文件列表错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.delete("/api/files/{file_id}")
async def delete_file(file_id: int):
    """删除文件"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # 获取文件信息
        cursor.execute("SELECT file_path FROM submit WHERE id = %s", (file_id,))
        file_info = cursor.fetchone()

        if not file_info:
            conn.close()
            raise HTTPException(status_code=404, detail="文件记录不存在")

        file_path = file_info['file_path']

        # 删除数据库记录
        cursor.execute("DELETE FROM submit WHERE id = %s", (file_id,))

        conn.commit()
        conn.close()

        # 删除物理文件（如果存在）
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"删除物理文件失败: {e}")
                # 不抛出错误，因为数据库记录已经删除了

        return {"success": True, "message": "文件删除成功"}

    except HTTPException:
        raise
    except Exception as e:
        print(f"删除文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")

@router.get("/api/files/{file_id}/download")
async def download_file(file_id: int):
    """下载文件"""
    try:
        conn = database.get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT file_name, file_path FROM submit WHERE id = %s", (file_id,))
        file_info = cursor.fetchone()

        conn.close()

        if not file_info:
            raise HTTPException(status_code=404, detail="文件不存在")

        if not os.path.exists(file_info['file_path']):
            raise HTTPException(status_code=404, detail="文件不存在")

        # 根据文件扩展名设置正确的MIME类型
        filename = file_info['file_name']
        file_ext = filename.lower().split('.')[-1] if '.' in filename else ''

        mime_types = {
            'pdf': 'application/pdf',
            'doc': 'application/msword',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls': 'application/vnd.ms-excel',
            'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'ppt': 'application/vnd.ms-powerpoint',
            'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'txt': 'text/plain',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'zip': 'application/zip',
            'rar': 'application/x-rar-compressed'
        }

        media_type = mime_types.get(file_ext, 'application/octet-stream')

        return FileResponse(
            path=file_info['file_path'],
            filename=filename,  # 确保使用原始文件名
            media_type=media_type
        )

    except HTTPException:
        raise
    except Exception as e:
        print(f"下载文件错误: {e}")
        raise HTTPException(status_code=500, detail=f"服务器错误: {str(e)}")
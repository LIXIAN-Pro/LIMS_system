import pymysql

def get_db_connection():
    """获取数据库连接"""
    connection = pymysql.connect(
        host='localhost',
        user='root',
        password='594332303lx.',
        database='lims_system',
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )
    return connection

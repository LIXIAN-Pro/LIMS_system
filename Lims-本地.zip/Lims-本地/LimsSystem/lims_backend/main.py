from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
import os
import sys


# 导入路由模块
from routes import auth, lab_info, personnel, entrust_units, collectors, equipment, agentia, projects, collection_templates, tasks, tasks_management, task_submissions, samples, experiment_reports, experiment_edit_reports, project_end, system_settings

app = FastAPI(title="LIMS系统后端", version="1.0.0")

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(auth.router)
app.include_router(lab_info.router)
app.include_router(personnel.router)
app.include_router(entrust_units.router)
app.include_router(collectors.router)
app.include_router(equipment.router)
app.include_router(agentia.router)
app.include_router(projects.router)
app.include_router(collection_templates.router)
app.include_router(tasks.router)
app.include_router(tasks_management.router)
app.include_router(task_submissions.router)
app.include_router(samples.router)
app.include_router(experiment_reports.router)
app.include_router(experiment_edit_reports.router)
app.include_router(project_end.router)
app.include_router(system_settings.router)


def initialize_database():
    """检查并初始化数据库"""
    try:
        from database import get_db_connection
        from init_database import create_database_schema, insert_initial_data, execute_sql_file

        print("🔍 检查数据库连接...")
        conn = get_db_connection()
        cursor = conn.cursor()

        # 检查数据库表是否已存在
        cursor.execute("SHOW TABLES LIKE 'lab_staff'")
        table_exists = cursor.fetchone()

        if not table_exists:
            print("📋 数据库表不存在，开始初始化...")
            print("=" * 50)

            try:
                # 1. 创建表结构
                print("📋 创建数据库表结构...")
                schema_sql = create_database_schema()
                execute_sql_file(cursor, schema_sql)

                # 2. 插入初始数据
                print("\n📝 插入初始数据...")
                initial_data_sql = insert_initial_data()
                execute_sql_file(cursor, initial_data_sql)

                # 提交事务
                conn.commit()

                print("\n✅ 数据库初始化完成！")
                print("=" * 50)
                print("👤 默认管理员账号: admin / admin")

            except Exception as e:
                print(f"\n❌ 初始化失败: {e}")
                conn.rollback()
                raise e
        else:
            print("✅ 数据库已初始化，跳过初始化步骤")

        conn.close()

    except Exception as e:
        print(f"❌ 数据库初始化检查失败: {e}")
        print("请确保MySQL服务已启动且数据库配置正确")
        sys.exit(1)


@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "LIMS Backend", "time": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn

    print("🚀 启动LIMS后端服务...")
    print("📊 数据库: lims_system")

    # 自动初始化数据库
    initialize_database()

    print("🌐 服务地址: http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
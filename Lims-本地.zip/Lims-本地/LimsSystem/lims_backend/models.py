from datetime import datetime, date
from typing import List, Optional
from pydantic import BaseModel

# 用户认证相关模型
class LoginRequest(BaseModel):
    username: str
    password: str
    role: str

# 实验室信息相关模型
class LabInfoCreate(BaseModel):
    name: str
    director: str
    code: str
    phone: str
    address: str
    description: Optional[str] = None
    logo: Optional[str] = None
    status: str = "active"

# 实验人员相关模型
class PersonnelCreate(BaseModel):
    name: str
    employee_id: str
    phone: str
    department: str
    responsibility: Optional[str] = None
    status: str = "active"

class PersonnelUpdate(PersonnelCreate):
    pass

# 委托单位相关模型
class EntrustUnitCreate(BaseModel):
    unit_name: str
    contact_person: str
    phone: str
    email: Optional[str] = None
    province: str
    city: str
    address: str
    status: str = "active"

class EntrustUnitUpdate(EntrustUnitCreate):
    pass

# 采集人员相关模型
class CollectorCreate(BaseModel):
    name: str
    employee_id: str
    phone: str
    status: str = "active"  # 确保有这个字段

class CollectorUpdate(CollectorCreate):
    pass

# 设备管理相关模型
class EquipmentCreate(BaseModel):
    name: str
    equipment_code: str
    collection_type: str
    location: Optional[str] = None
    status: str = "idle"  # 修改：默认值为 idle

class EquipmentUpdate(EquipmentCreate):
    pass

# 采样试剂管理相关模型
class AgentiaCreate(BaseModel):
    name: str
    agentia_code: str
    capacity: int
    quantity: int = 0
    status: str = "available"  # 新增：状态字段

class AgentiaUpdate(AgentiaCreate):
    pass

class AgentiaQuantityUpdate(BaseModel):
    quantity: int

# 项目管理相关模型
class ProjectCreate(BaseModel):
    project_code: str
    project_name: str
    entrust_unit_id: int
    test_type: str
    collection_type: str
    location: Optional[str] = None
    description: Optional[str] = None
    status: str = "planning"

class ProjectUpdate(ProjectCreate):
    pass

# 样品管理相关模型
class SampleCreate(BaseModel):
    project_id: int
    sample_type: str  # 'collection' 或 'delivery'
    sample_code: Optional[str] = None  # 样品编号，格式：YP-项目编号
    entry_time: Optional[datetime] = None
    status: str = "active"
    notes: Optional[str] = None

class SampleUpdate(BaseModel):
    status: Optional[str] = None
    notes: Optional[str] = None

class SampleEntryRequest(BaseModel):
    project_id: int
    sample_type: str  # 'collection' 或 'delivery'

# 实验报告相关模型
class ExperimentReportCreate(BaseModel):
    project_id: int
    personnel_id: int
    notes: Optional[str] = None

class ExperimentReportResponse(BaseModel):
    id: int
    project_id: int
    project_code: str
    project_name: str
    personnel_id: int
    personnel_name: str
    report_filename: str
    original_filename: str
    file_path: str
    file_size: Optional[int] = None
    upload_time: datetime
    status: str
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime

# 实验编制报告相关模型
class ExperimentEditReportCreate(BaseModel):
    experiment_report_id: int
    notes: Optional[str] = None

class ExperimentEditReportResponse(BaseModel):
    id: int
    experiment_report_id: int
    project_code: str
    project_name: str
    personnel_name: str
    filename: str
    original_filename: str
    file_path: str
    file_size: Optional[int] = None
    notes: Optional[str] = None
    upload_time: datetime
    status: str

# 系统设置相关模型
class SystemSettingCreate(BaseModel):
    setting_key: str
    setting_value: Optional[str] = None
    setting_group: str = "general"
    description: Optional[str] = None
    is_encrypted: bool = False

class SystemSettingUpdate(BaseModel):
    setting_value: Optional[str] = None
    description: Optional[str] = None
    is_encrypted: Optional[bool] = None

class SystemSettingResponse(BaseModel):
    id: int
    setting_key: str
    setting_value: Optional[str] = None
    setting_group: str
    description: Optional[str] = None
    is_encrypted: bool
    created_at: datetime
    updated_at: datetime

# SMTP邮箱设置相关模型
class SmtpSettings(BaseModel):
    server: str
    port: int
    sender_email: str
    sender_password: str
    sender_name: Optional[str] = None
    use_ssl: bool = True

class TestEmailSendRequest(BaseModel):
    recipient: str
    subject: Optional[str] = "LIMS系统邮件测试"
    content: Optional[str] = "这是一封测试邮件，用于验证SMTP配置是否正确。"
# LIMS系统数据库初始化指南

## 概述

本项目包含了环境检测实验室管理系统(LIMS)的完整数据库初始化方案，提供了两种初始化方式：Python脚本和SQL脚本。

## 数据库结构

系统包含以下16个核心数据表：

1. **system_settings** - 系统设置表
2. **laboratory_info** - 实验室信息表
3. **lab_staff** - 用户表（实验室工作人员）
4. **lab_personnel** - 实验人员表
5. **entrust_units** - 委托单位表
6. **collectors** - 采集人员表
7. **equipment** - 设备表
8. **agentia** - 试剂表
9. **projects** - 项目表
10. **tasks** - 任务表
11. **task_collectors** - 任务采集人员关联表
12. **sample** - 样品表
13. **experiment_reports** - 实验报告表
14. **experiment_edit_reports** - 实验编辑报告表
15. **collection_templates** - 采集模板表
16. **submit** - 任务提交文件表

### 系统设置表说明

**system_settings** 表用于存储系统的各种配置信息：

- **setting_key**: 配置项的唯一标识符
- **setting_value**: 配置项的值
- **setting_group**: 配置分组（如：smtp, general等）
- **description**: 配置项的描述
- **is_encrypted**: 是否加密存储（用于敏感信息）

**当前支持的配置分组：**
- `smtp`: SMTP邮件服务器配置
- `general`: 通用系统配置（预留扩展）

**SMTP配置示例：**
```sql
-- 查看SMTP配置
SELECT setting_key, setting_value FROM system_settings
WHERE setting_group = 'smtp' ORDER BY setting_key;
```

## 初始化方式

### 方式一：Python脚本初始化（推荐）

#### 环境要求
- Python 3.7+
- pymysql库：`pip install pymysql`

#### 使用步骤
1. 确保MySQL服务已启动
2. 修改`init_database.py`中的数据库连接配置：
   ```python
   DB_CONFIG = {
       'host': 'localhost',
       'user': 'root',  # 修改为你的MySQL用户名
       'password': 'your_password',  # 修改为你的MySQL密码
       'database': 'lims_system',
       'charset': 'utf8mb4',
       'cursorclass': pymysql.cursors.DictCursor
   }
   ```
3. 运行脚本：
   ```bash
   cd lims_backend
   python init_database.py
   ```

#### 脚本特性
- 自动创建数据库和表结构（16个核心表）
- 自动添加外键约束和索引
- 自动插入初始测试数据
- 智能SQL语句解析（支持注释和复杂语句）
- 错误处理和回滚机制
- 详细的执行日志

### 方式二：SQL脚本初始化

#### 环境要求
- MySQL 5.7+ 或 MariaDB 10.0+

#### 使用步骤
1. 确保MySQL服务已启动
2. 使用mysql命令行工具执行脚本：
   ```bash
   mysql -u root -p < init_database.sql
   ```
   或者在MySQL客户端中：
   ```sql
   SOURCE init_database.sql;
   ```

## 初始数据说明

脚本会自动创建以下初始数据：

### 默认管理员账号
- **管理员**: `admin` / `admin`

## 数据库配置

### MySQL配置要求
```sql
-- 确保MySQL支持UTF8MB4字符集
SHOW VARIABLES LIKE 'character_set%';

-- 如果不支持，需要修改my.cnf配置
[mysqld]
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci

[mysql]
default-character-set=utf8mb4
```

### 权限配置
确保数据库用户具有以下权限：
- CREATE DATABASE
- CREATE TABLE
- ALTER TABLE
- INSERT, UPDATE, DELETE, SELECT

## 验证初始化结果

初始化完成后，可以通过以下方式验证：

### 1. 检查数据库和表
```sql
SHOW DATABASES;
USE lims_system;
SHOW TABLES;
```

### 2. 检查数据
```sql
-- 查看系统设置
SELECT setting_key, setting_value, setting_group FROM system_settings ORDER BY setting_group, setting_key;

-- 查看用户
SELECT id, username, role, name FROM lab_staff;

-- 查看实验人员
SELECT id, name, employee_id, department FROM lab_personnel;

-- 查看设备
SELECT id, name, equipment_code, status FROM equipment;
```

### 3. 启动后端服务
```bash
python main.py
```

服务启动后访问 `http://127.0.0.1:8000/health` 验证服务状态。

## 故障排除

### 常见问题

1. **连接失败**
   - 检查MySQL服务是否启动
   - 验证用户名和密码
   - 检查网络连接

2. **权限不足**
   - 确保用户有CREATE DATABASE权限
   - 检查数据库用户权限设置

3. **字符集问题**
   - 确保MySQL支持UTF8MB4
   - 检查数据库和表的字符集设置

4. **表已存在**
   - 脚本使用了`IF NOT EXISTS`和`INSERT IGNORE`，可以安全重复运行
   - 如需重新初始化，可先删除数据库

### 日志查看
Python脚本会输出详细的执行日志，SQL脚本执行时会显示执行状态。

## 安全注意事项

1. **生产环境使用**
   - 修改默认密码
   - 使用强密码策略
   - 定期更新密码

2. **数据库备份**
   - 初始化前备份现有数据
   - 定期备份生产数据库

3. **网络安全**
   - 使用内网访问数据库
   - 配置防火墙规则
   - 启用SSL连接（如需要）

## 技术支持

如遇到问题，请检查：
1. MySQL版本和配置
2. Python环境和依赖包
3. 数据库用户权限
4. 网络连接状态
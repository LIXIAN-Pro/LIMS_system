/*
 Navicat Premium Dump SQL

 Source Server         : 本地MySQL
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : localhost:3306
 Source Schema         : lims_system

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 13/01/2026 15:45:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for system_settings
-- ----------------------------
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL COMMENT '设置键名',
  `setting_value` text COMMENT '设置值',
  `setting_group` varchar(50) NOT NULL DEFAULT 'general' COMMENT '设置分组',
  `description` varchar(255) DEFAULT NULL COMMENT '设置描述',
  `is_encrypted` tinyint(1) DEFAULT '0' COMMENT '是否加密存储',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_setting_key` (`setting_key`),
  KEY `idx_setting_group` (`setting_group`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统设置表';

-- ----------------------------
-- Table structure for agentia
-- ----------------------------
DROP TABLE IF EXISTS `agentia`;
CREATE TABLE `agentia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '试剂名称',
  `agentia_code` varchar(50) NOT NULL COMMENT '试剂编号',
  `capacity` int NOT NULL COMMENT '容量(ml)',
  `quantity` int NOT NULL DEFAULT '0' COMMENT '仓库数量' CHECK (`quantity` >= 0),
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `status` enum('available','low_stock','out_of_stock') DEFAULT 'available' COMMENT '试剂状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `agentia_code` (`agentia_code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采样试剂信息表';

-- ----------------------------
-- Table structure for collection_templates
-- ----------------------------
DROP TABLE IF EXISTS `collection_templates`;
CREATE TABLE `collection_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文件名',
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文件存储路径',
  `file_size` bigint NOT NULL COMMENT '文件大小（字节）',
  `file_format` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '文件格式',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='采集表模板表';

-- ----------------------------
-- Table structure for collectors
-- ----------------------------
DROP TABLE IF EXISTS `collectors`;
CREATE TABLE `collectors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `employee_id` varchar(20) NOT NULL COMMENT '工号',
  `phone` varchar(20) NOT NULL COMMENT '联系电话',
  `status` enum('active','inactive') DEFAULT 'active' COMMENT '状态：active-在职，inactive-离职',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采集人员信息表';

-- ----------------------------
-- Table structure for entrust_units
-- ----------------------------
DROP TABLE IF EXISTS `entrust_units`;
CREATE TABLE `entrust_units` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '单位ID',
  `unit_name` varchar(100) NOT NULL COMMENT '委托单位名称',
  `contact_person` varchar(50) NOT NULL COMMENT '负责人姓名',
  `phone` varchar(20) NOT NULL COMMENT '联系电话',
  `email` varchar(100) DEFAULT NULL COMMENT '电子邮箱',
  `province` varchar(50) NOT NULL COMMENT '省份',
  `city` varchar(50) NOT NULL COMMENT '城市',
  `address` varchar(200) NOT NULL COMMENT '具体地址',
  `status` enum('active','inactive') DEFAULT 'active' COMMENT '状态：active-正常，inactive-停用',
  `user_id` int DEFAULT NULL COMMENT '操作人ID',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_phone` (`phone`),
  KEY `idx_unit_name` (`unit_name`),
  KEY `idx_contact_person` (`contact_person`),
  KEY `idx_province` (`province`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='委托单位信息表';

-- ----------------------------
-- Table structure for equipment
-- ----------------------------
DROP TABLE IF EXISTS `equipment`;
CREATE TABLE `equipment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '设备名称',
  `equipment_code` varchar(30) NOT NULL COMMENT '设备编号',
  `collection_type` enum('wastewater','wastegas','particle') NOT NULL COMMENT '采集类型：wastewater-废水，wastegas-废气，particle-颗粒',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `location` varchar(255) DEFAULT NULL,
  `status` enum('idle','in_use','maintenance') DEFAULT 'idle' COMMENT '设备状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_code` (`equipment_code`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备信息表';

-- ----------------------------
-- Table structure for experiment_edit_reports
-- ----------------------------
DROP TABLE IF EXISTS `experiment_edit_reports`;
CREATE TABLE `experiment_edit_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `experiment_report_id` int NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `upload_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('uploaded','processing','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'uploaded',
  `review_level` tinyint DEFAULT '1' COMMENT '审核级别：1=待二级审核，2=二级审核通过待三级审核，3=三级审核通过，4=审核完成',
  `review_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending' COMMENT '审核状态',
  `review_notes` text COLLATE utf8mb4_unicode_ci COMMENT '审核备注',
  `reviewed_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核人',
  `reviewed_at` datetime DEFAULT NULL COMMENT '审核时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_experiment_report` (`experiment_report_id`),
  KEY `idx_experiment_report_id` (`experiment_report_id`),
  KEY `idx_upload_time` (`upload_time`),
  KEY `idx_status` (`status`),
  CONSTRAINT `experiment_edit_reports_ibfk_1` FOREIGN KEY (`experiment_report_id`) REFERENCES `experiment_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='报告编制表\n';

-- ----------------------------
-- Table structure for experiment_reports
-- ----------------------------
DROP TABLE IF EXISTS `experiment_reports`;
CREATE TABLE `experiment_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `project_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personnel_id` int NOT NULL,
  `personnel_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int DEFAULT NULL,
  `upload_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('uploaded','processing','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'uploaded',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_project_id` (`project_id`),
  KEY `idx_personnel_id` (`personnel_id`),
  KEY `idx_upload_time` (`upload_time`),
  KEY `idx_status` (`status`),
  KEY `idx_project_personnel` (`project_id`,`personnel_id`),
  CONSTRAINT `experiment_reports_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `experiment_reports_ibfk_2` FOREIGN KEY (`personnel_id`) REFERENCES `lab_personnel` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='实验报告表';

-- ----------------------------
-- Table structure for lab_personnel
-- ----------------------------
DROP TABLE IF EXISTS `lab_personnel`;
CREATE TABLE `lab_personnel` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '人员ID',
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `employee_id` varchar(20) NOT NULL COMMENT '工号',
  `phone` varchar(20) NOT NULL COMMENT '联系电话',
  `department` varchar(50) NOT NULL COMMENT '所在科室',
  `responsibility` text COMMENT '负责内容',
  `status` enum('active','inactive') DEFAULT 'active' COMMENT '状态：active-在职，inactive-离职',
  `user_id` int DEFAULT NULL COMMENT '操作人ID（创建/修改人）',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `idx_employee_id` (`employee_id`),
  KEY `idx_department` (`department`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='实验人员表';

-- ----------------------------
-- Table structure for lab_staff
-- ----------------------------
DROP TABLE IF EXISTS `lab_staff`;
CREATE TABLE `lab_staff` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('manager','staff','viewer') DEFAULT 'staff',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(100) DEFAULT NULL COMMENT '用户姓名',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱地址',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户登录表';

-- ----------------------------
-- Table structure for laboratory_info
-- ----------------------------
DROP TABLE IF EXISTS `laboratory_info`;
CREATE TABLE `laboratory_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `director` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `logo` longtext COLLATE utf8mb4_unicode_ci,
  `status` enum('active','maintenance','closed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='实验室信息表';

-- ----------------------------
-- Table structure for projects
-- ----------------------------
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_code` varchar(50) NOT NULL COMMENT '项目编号',
  `project_name` varchar(200) NOT NULL COMMENT '项目名称',
  `entrust_unit_id` int NOT NULL COMMENT '委托单位ID',
  `test_type` varchar(50) NOT NULL COMMENT '检测类型',
  `collection_type` varchar(20) NOT NULL COMMENT '采集方式：采样/送样',
  `location` varchar(500) DEFAULT NULL COMMENT '采集位置',
  `description` text COMMENT '项目描述',
  `status` enum('planning','in_progress','completed') DEFAULT 'planning' COMMENT '项目状态',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `sample_status` enum('pending','entered') DEFAULT 'pending' COMMENT '样品入库状态：pending=待入库，entered=已入库',
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_code` (`project_code`),
  KEY `entrust_unit_id` (`entrust_unit_id`),
  CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`entrust_unit_id`) REFERENCES `entrust_units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='项目信息表';

-- ----------------------------
-- Table structure for sample
-- ----------------------------
DROP TABLE IF EXISTS `sample`;
CREATE TABLE `sample` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sample_code` varchar(100) DEFAULT NULL,
  `project_id` int NOT NULL,
  `sample_type` enum('collection','delivery') NOT NULL COMMENT '样品类型：collection=采集样品，delivery=送样样品',
  `entry_time` datetime NOT NULL COMMENT '入库时间',
  `status` enum('active','archived','discarded') DEFAULT 'active' COMMENT '状态',
  `notes` text COMMENT '备注',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_project_sample` (`project_id`,`sample_type`),
  UNIQUE KEY `sample_code` (`sample_code`),
  CONSTRAINT `sample_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='样品信息表';

-- ----------------------------
-- Table structure for submit
-- ----------------------------
DROP TABLE IF EXISTS `submit`;
CREATE TABLE `submit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` int NOT NULL,
  `project_code` varchar(50) NOT NULL COMMENT '关联项目编号',
  `file_name` varchar(255) NOT NULL COMMENT '原始文件名',
  `file_path` varchar(500) NOT NULL COMMENT '文件存储路径',
  `file_size` bigint DEFAULT NULL COMMENT '文件大小（字节）',
  `upload_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '上传时间',
  `submitter_id` int DEFAULT NULL COMMENT '提交者ID',
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_upload_time` (`upload_time`),
  KEY `idx_project_code` (`project_code`),
  CONSTRAINT `submit_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='任务提交文件表';

-- ----------------------------
-- Table structure for task_collectors
-- ----------------------------
DROP TABLE IF EXISTS `task_collectors`;
CREATE TABLE `task_collectors` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '关联ID',
  `task_id` int NOT NULL COMMENT '任务ID',
  `collector_id` int NOT NULL COMMENT '采集人员ID',
  `collector_name` varchar(50) NOT NULL COMMENT '采集人员姓名（冗余存储）',
  `collector_employee_id` varchar(50) NOT NULL COMMENT '采集人员工号（冗余存储）',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_task_collector` (`task_id`,`collector_id`),
  KEY `collector_id` (`collector_id`),
  KEY `idx_task_collector` (`task_id`,`collector_id`),
  CONSTRAINT `task_collectors_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `task_collectors_ibfk_2` FOREIGN KEY (`collector_id`) REFERENCES `collectors` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='任务采集人员关联表';

-- ----------------------------
-- Table structure for tasks
-- ----------------------------
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `task_code` varchar(50) NOT NULL COMMENT '任务编号，格式：TASK-YYMMDD-序列号',
  `project_id` int NOT NULL COMMENT '项目ID',
  `project_code` varchar(50) NOT NULL COMMENT '项目编号（冗余存储）',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `equipment_id` int DEFAULT NULL COMMENT '设备ID',
  `agentia_id` int DEFAULT NULL COMMENT '试剂ID',
  `template_id` int DEFAULT NULL COMMENT '表单模板ID',
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending' COMMENT '任务状态',
  `created_by` varchar(50) DEFAULT NULL COMMENT '创建人',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_code` (`task_code`),
  KEY `equipment_id` (`equipment_id`),
  KEY `agentia_id` (`agentia_id`),
  KEY `template_id` (`template_id`),
  KEY `idx_task_code` (`task_code`),
  KEY `idx_project` (`project_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `tasks_ibfk_3` FOREIGN KEY (`agentia_id`) REFERENCES `agentia` (`id`),
  CONSTRAINT `tasks_ibfk_4` FOREIGN KEY (`template_id`) REFERENCES `collection_templates` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='任务表';

-- ----------------------------
-- View structure for task_details
-- ----------------------------
DROP VIEW IF EXISTS `task_details`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `task_details` AS select `t`.`id` AS `id`,`t`.`task_code` AS `task_code`,`t`.`project_id` AS `project_id`,`t`.`project_code` AS `project_code`,`p`.`project_name` AS `project_name`,`p`.`entrust_unit_id` AS `entrust_unit_id`,`e`.`unit_name` AS `entrust_unit_name`,date_format(`t`.`start_time`,'%Y-%m-%d %H:%i') AS `start_time`,date_format(`t`.`end_time`,'%Y-%m-%d %H:%i') AS `end_time`,`t`.`equipment_id` AS `equipment_id`,`eq`.`name` AS `equipment_name`,`t`.`agentia_id` AS `agentia_id`,`a`.`name` AS `agentia_name`,`t`.`status` AS `status`,date_format(`t`.`created_at`,'%Y-%m-%d %H:%i') AS `issued_at`,group_concat(distinct concat(`c`.`name`,'(',`c`.`employee_id`,')') order by `c`.`name` ASC separator '、') AS `collectors`,group_concat(distinct `c`.`id` separator ',') AS `collector_ids`,group_concat(distinct `c`.`name` separator ',') AS `collector_names`,count(distinct `tc`.`collector_id`) AS `collector_count` from `tasks` `t` left join `projects` `p` on(`t`.`project_id` = `p`.`id`) left join `entrust_units` `e` on(`p`.`entrust_unit_id` = `e`.`id`) left join `equipment` `eq` on(`t`.`equipment_id` = `eq`.`id`) left join `agentia` `a` on(`t`.`agentia_id` = `a`.`id`) left join `task_collectors` `tc` on(`t`.`id` = `tc`.`task_id`) left join `collectors` `c` on(`tc`.`collector_id` = `c`.`id`) group by `t`.`id` order by `t`.`created_at` desc;

SET FOREIGN_KEY_CHECKS = 1;
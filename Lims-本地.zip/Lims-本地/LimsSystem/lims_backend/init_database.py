#!/usr/bin/env python3
"""
LIMS系统数据库初始化脚本
用于创建数据库表结构、约束、索引和初始数据
"""

import pymysql
import sys
from datetime import datetime

# 数据库配置（与database.py保持一致）
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '594332303lx.',
    'database': 'lims_system',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    """获取数据库连接"""
    try:
        connection = pymysql.connect(**DB_CONFIG)
        return connection
    except pymysql.Error as e:
        print(f"数据库连接失败: {e}")
        sys.exit(1)

def execute_sql_file(cursor, sql_file_content):
    """执行SQL文件内容"""
    # 移除注释和空行，分割SQL语句
    import re

    # 移除单行注释 (--)
    sql_content = re.sub(r'--.*$', '', sql_file_content, flags=re.MULTILINE)

    # 移除多行注释 (/* ... */)
    sql_content = re.sub(r'/\*.*?\*/', '', sql_content, flags=re.DOTALL)

    # 按分号分割，但避免在字符串和括号内分割
    statements = []
    current_statement = []
    in_string = False
    string_char = None
    in_brackets = 0

    for char in sql_content:
        if in_string:
            if char == string_char:
                in_string = False
                string_char = None
            current_statement.append(char)
        elif char in ('"', "'"):
            in_string = True
            string_char = char
            current_statement.append(char)
        elif char == '(':
            in_brackets += 1
            current_statement.append(char)
        elif char == ')':
            in_brackets -= 1
            current_statement.append(char)
        elif char == ';' and in_brackets == 0:
            statement = ''.join(current_statement).strip()
            if statement:
                statements.append(statement)
            current_statement = []
        else:
            current_statement.append(char)

    # 处理最后一个语句（如果没有分号结尾）
    statement = ''.join(current_statement).strip()
    if statement:
        statements.append(statement)

    executed_count = 0
    for i, statement in enumerate(statements, 1):
        statement = statement.strip()
        if statement and not statement.startswith('--'):
            try:
                cursor.execute(statement)
                executed_count += 1
                # 只显示前几个字符，避免输出过长
                preview = statement.replace('\n', ' ').replace('\r', ' ')[:60]
                if len(statement) > 60:
                    preview += '...'
                print(f"✓ 执行成功 [{i}]: {preview}")
            except pymysql.Error as e:
                print(f"✗ 执行失败 [{i}]: {statement.replace(chr(10), ' ')[:50]}... 错误: {e}")
                raise e

    print(f"📊 共执行了 {executed_count} 条SQL语句")

def create_database_schema():
    """创建数据库表结构"""

    try:
        # 读取外部SQL文件
        with open('init_database.sql', 'r', encoding='utf-8') as f:
            schema_sql = f.read()
    except FileNotFoundError:
        print("❌ 错误: 找不到 init_database.sql 文件")
        sys.exit(1)
    except Exception as e:
        print(f"❌ 读取SQL文件错误: {e}")
        sys.exit(1)

    return schema_sql

def insert_initial_data():
    """插入初始数据"""

    initial_data_sql = """
    -- 插入默认管理员用户
    INSERT IGNORE INTO lab_staff (username, password, role, name, email) VALUES
    ('admin', 'admin', 'manger', '系统管理员', 'admin@lab.com');
    """

    return initial_data_sql

def main():
    """主函数"""
    print("🚀 开始初始化LIMS系统数据库...")
    print("=" * 50)

    # 获取数据库连接
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # 1. 创建表结构
        print("📋 创建数据库表结构...")
        schema_sql = create_database_schema()
        execute_sql_file(cursor, schema_sql)
        print("✅ 数据库表结构创建完成")

        # 2. 插入初始数据
        print("📝 插入初始数据...")
        initial_data_sql = insert_initial_data()
        execute_sql_file(cursor, initial_data_sql)
        print("✅ 初始数据插入完成")

        conn.commit()

        print("\n✅ 数据库初始化完成！")
        print("=" * 50)
        print("📊 数据库: lims_system")
        print("👤 默认管理员账号: admin / admin")
        print("🌐 启动后端服务: python main.py")

    except Exception as e:
        print(f"\n❌ 初始化失败: {e}")
        conn.rollback()
        sys.exit(1)
    finally:
        conn.close()

if __name__ == "__main__":
    main()
